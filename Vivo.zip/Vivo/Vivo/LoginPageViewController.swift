//
//  LoginPageViewController.swift
//  Vivo
//
//  Created by Evgeny KUZNETSOV on 10/27/15.
//  Copyright (c) 2015 Evgeny KUZNETSOV. All rights reserved.
//

import UIKit

class LoginPageViewController: UIViewController {

    // define our UI elements in the code
    
    //labels
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var password: UILabel!
    // text fields
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    // login button
    @IBAction func Login(sender: AnyObject){
        
        //perform validation of the password against the db http post
        
        // if valid more to the app
        
        //else display error message
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
