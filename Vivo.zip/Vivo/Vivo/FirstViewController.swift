//
//  FirstViewController.swift
//  Vivo
//
//  Created by Evgeny KUZNETSOV on 10/27/15.
//  Copyright (c) 2015 Evgeny KUZNETSOV. All rights reserved.
//

import UIKit
import CoreMotion

class FirstViewController: UIViewController {

    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var Xvalue: UILabel!
    
    @IBOutlet weak var Yvalue: UILabel!
    
    @IBOutlet weak var angle: UILabel!
    
    @IBOutlet weak var activateText: UILabel!
    
    @IBOutlet weak var fallDetectionState: UISwitch!
    
    @IBAction func switchFallDetection(sender: AnyObject)
    {
        if (fallDetectionState.on)
        {
            self.activateText.text = "Fall detection is activated!"
            println("Is on")
            if (motionManager.accelerometerAvailable && fallDetectionState.on)
            {
                motionManager.accelerometerUpdateInterval = 0.01
                motionManager.startDeviceMotionUpdatesToQueue(NSOperationQueue.mainQueue()){
                    
                    [weak self] (data: CMDeviceMotion!, error: NSError!) in
                    let rotation = atan2(data.gravity.x, data.gravity.y) - M_PI
                    
                    self?.status.text="Activated"
                    
                    var xString:String = String(format:"%f", data.gravity.x)
                    self?.Xvalue.text=xString
                    
                    var yString:String = String(format:"%f", data.gravity.y)
                    self?.Yvalue.text=yString
                    
                    var rotationString:String = String(format:"%f", rotation)
                    self?.angle.text=rotationString
                }
                
            }
            else
            {
                println("motion is not availuable")
                self.status.text="Failed"
                self.Xvalue.text="NaN"
                self.Yvalue.text="NaN"
                self.angle.text="NaN"
            }
        }
        else
        {
            self.activateText.text = "Flip the switch to activate!"
            println("Is off")
        }
    }
    
    let motionManager = CMMotionManager()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        fallDetectionState.setOn(false, animated: true)
        
        
        // Do any additional setup after loading the view, typically from a nib.


    }
    
        override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

// https://github.com/nmarkovic04/Phoney
