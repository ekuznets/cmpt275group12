//
//  PillSearchViewController.swift
//  PillShow
//
//  Created by hong qiu on 2015-11-05.
//  Copyright (c) 2015 hong qiu. All rights reserved.
//

//self pill array search function
//search by name
//func pillSearchName (var pills: [Pill], name: String) -> Pill {
//    for i in 0..<pills.count
//    {
//        
//        let currentPill = pills[i]
//        
//        if (currentPill.getPillName() == name)
//        {
//            return currentPill
//        }
//    }
//    // a pill to say that we have not found it in a list
//    let myPill=Pill(name:"Not Exist",DIN: "000000", description: "000000")
//    return myPill
//}
//
////search by DIN
//func pillSearchDin (var pills: [Pill], DIN: String) -> Pill {
//    for i in 0..<pills.count {
//        
//        let currentPill = pills[i]
//        
//        if (currentPill.getPillDin() == DIN) {
//            return currentPill
//        }
//        
//    }
//    // a pill to say that we have not found it in a list
//    let myPill=Pill(name:"Not Exist",DIN: "000000", description: "000000")
//    return myPill
//}


import UIKit



// pillArray store pill when match
var listArray = [Pill]()

class PillSearchViewController: UIViewController {
    //user input text
    @IBOutlet weak var pillToLook: UITextField!
    //print search result
    @IBOutlet weak var searchResultText: UILabel!
    
    //boolean search function
    @IBAction func pillSearchAction(sender: AnyObject) {
        
//        for item in pillWholeArray {
//            if item.getPillName() == pillToLook.text {
//                listArray.append(item)
//                searchResultText.text = " Pill Added"
//            }
//            else{
//                searchResultText.text = " fail"
//            }
//        }
//        
//        println(listArray)
//        println(pillWholeArray.count)
//        
//        for item in pillWholeArray {
//            if item.getPillName() == pillToLook.text {
//                searchResultText.text = (item.printPill())
//            }
//        }
        
        //simpletextfield get first responder
        self.pillToLook.resignFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //let currenPill=
        
        //read pill from text file
        
    
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}













