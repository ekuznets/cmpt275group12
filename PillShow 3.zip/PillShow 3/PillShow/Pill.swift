//
//  Pill.swift
//  PillShow
//
//  Created by hong qiu on 2015-11-05.
//  Copyright (c) 2015 hong qiu. All rights reserved.
//


public class Pill{
    //stored properties
    var name: String
    var DIN: String
    var description: String
    
    //default initializer
    init() {
        name = ""
        DIN = ""
        description = ""
        
    }
    
    //Parameterized initializer
    init(name: String, DIN: String, description: String){
        self.name = name
        self.DIN = DIN
        self.description = description
    }
    
    //return pill description
    func printPill()-> String {
        return  "\(name) instrcution: " + "\(description)"
    }
    
    //return pill name
    func getPillName() -> String{
        return self.name
    }
    
    //return pill DIN
    func getPillDin() -> String{
        return self.DIN
    }
    
    //return pill description
    func getPillDescription() -> String{
        return self.description
    }
    
    
    
}
