//
//  currentPillViewController.swift
//  PillShow
//
//  Created by hong qiu on 2015-11-05.
//  Copyright (c) 2015 hong qiu. All rights reserved.
//


import UIKit


class currentPillViewController: UIViewController {
    
    var currentPill : Pill?

    @IBOutlet weak var timePacker: UIDatePicker!
    @IBOutlet weak var labeloutput: UILabel!
    
    @IBAction func displayTime(sender: AnyObject) {
       // grab a time
       //var chosenDate = self.timePacker.date
        var formatter = NSDateFormatter()
        
        formatter.dateFormat = "dd/MM/YYYY HH:mm a"
        var strDate = formatter.stringFromDate(timePacker.date)
        
        labeloutput.text = strDate
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        print(Pill)
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
