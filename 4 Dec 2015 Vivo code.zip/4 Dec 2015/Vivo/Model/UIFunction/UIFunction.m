//
//  UiFunction.m
//  FakhrooUpdationApp
//
//  Created by Sukhreet on 3/5/15.
//  Copyright (c) 2015 Apto. All rights reserved.
//

#import "UIFunction.h"
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <AddressBook/AddressBook.h>
#import <AddressBook/ABAddressBook.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>

#define REGEX_PASSWORD_ONE_UPPERCASE @"^(?=.*[A-Z]).*$"  //Should contains one or more uppercase letters
#define REGEX_PASSWORD_ONE_LOWERCASE @"^(?=.*[a-z]).*$"  //Should contains one or more lowercase letters
#define REGEX_PASSWORD_ONE_NUMBER @"^(?=.*[0-9]).*$"  //Should contains one or more number
#define REGEX_PASSWORD_ONE_SYMBOL @"^(?=.*[!@#$%&_]).*$"  //Should contains one or more symbol


@implementation UIFunction


#pragma mark
#pragma mark<UIAlertView Helpers>
#pragma mark



#pragma mark
#pragma mark Method to Create UIButton UI
+(UIButton*)createButton:(CGRect)frame bckgroundColor:(UIColor*)backgroundColor image:(UIImage*)image title:(NSString*)title font:(UIFont*)font titleColor:(UIColor*)titleColor
{
    UIButton *_button = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    _button.backgroundColor = backgroundColor;
    _button.frame = frame;
    _button.exclusiveTouch = YES;
    [_button setTitle:title forState:UIControlStateNormal];
    [_button setTitleColor:titleColor forState:UIControlStateNormal];
    [_button setBackgroundImage:image forState:UIControlStateNormal];
    _button.titleLabel.font = font;
    return _button;
}

#pragma mark
#pragma mark Method to Create UILable UI
+(UILabel*)createLable:(CGRect)frame bckgroundColor:(UIColor*)backgroundColor title:(NSString*)title font:(UIFont*)font titleColor:(UIColor*)titleColor
{
    UILabel *_lable = [[UILabel alloc] init];
    _lable.backgroundColor = backgroundColor;
    _lable.frame = frame;
    _lable.text = title;
    _lable.textColor = titleColor;
    _lable.font = font;
    return _lable;
}

#pragma mark
#pragma mark Method to Create UIImageView UI
+(UIImageView*)createUIImageView:(CGRect)frame backgroundColor:(UIColor*)backgroundColor image:(UIImage*)image isLogo:(BOOL)isLogo
{
    UIImageView *_imageView = [[UIImageView alloc]initWithFrame:frame];
    _imageView.image = image;
    _imageView.backgroundColor = backgroundColor;
    return _imageView;
}


#pragma mark
#pragma mark Email Verificaton
+(BOOL) validateEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    NSString* emailRegex = @"[A-Z0-9a-z._%+]+@[A-Za-z0-9.]+\\.[A-Za-z]{2,4}";
    NSPredicate* emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    stricterFilter = [emailTest evaluateWithObject:checkString];
    return stricterFilter;
}


#pragma mark
#pragma mark Create Header
+(UIView*)createHeader:(CGRect)frame bckgroundColor:(UIColor*)backgroundColor
{
    UIView *_headerView = [[UIView alloc]init];
    _headerView.frame = frame;
    _headerView.backgroundColor = backgroundColor;
    _headerView.layer.masksToBounds = false;
    _headerView.layer.shadowColor = [UIColor grayColor].CGColor;
    _headerView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    _headerView.layer.shadowOpacity = 1.0;
    _headerView.layer.shadowRadius = 2.0;
    return _headerView;
}


#pragma mark
#pragma mark Create UIViews
+(UIView*)createUIViews : (CGRect)frame bckgroundColor:(UIColor*)backgroundColor
{
    UIView *_backGroundView = [[UIView alloc]init];
    _backGroundView.frame = frame;
    _backGroundView.backgroundColor = backgroundColor;
    return _backGroundView;
}


+(UITextField*)createTextField : (CGRect)frame font:(UIFont*)font placeholder:(NSString*)placeholder
{
    UITextField *_textField = [[UITextField alloc]init];
    _textField.frame = frame;
    _textField.borderStyle = UITextBorderStyleNone;
    _textField.font = [UIFont fontWithName:miscoRegular size:16];
    _textField.keyboardType = UIKeyboardTypeDefault;
    _textField.returnKeyType = UIReturnKeyDone;
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textField.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    _textField.secureTextEntry = NO;
    _textField.placeholder = placeholder;
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _textField.textColor = [UIColor blackColor];
    _textField.leftViewMode=UITextFieldViewModeAlways;
    _textField.autocapitalizationType= UITextAutocapitalizationTypeNone;
    _textField.autocorrectionType = UITextAutocorrectionTypeNo;
    _textField.backgroundColor = [UIColor clearColor];
    return _textField;
}


#pragma mark
#pragma mark Activity Indicator
+(UIActivityIndicatorView*)createActivityIndicatorView :(CGRect)frame
{
    UIActivityIndicatorView *_activityIndicator  = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    _activityIndicator.frame = frame;
    _activityIndicator.hidesWhenStopped = YES;
    _activityIndicator.color = [UIColor whiteColor];
    _activityIndicator.backgroundColor = [UIColor clearColor];
    return _activityIndicator;
}


#pragma mark
#pragma mark Activity Indicator
+ (NSString *)deviceUUID
{
    if([[NSUserDefaults standardUserDefaults] objectForKey:[[NSBundle mainBundle] bundleIdentifier]])
        return [[NSUserDefaults standardUserDefaults] objectForKey:[[NSBundle mainBundle] bundleIdentifier]];
    
    @autoreleasepool {
        
        CFUUIDRef uuidReference = CFUUIDCreate(nil);
        CFStringRef stringReference = CFUUIDCreateString(nil, uuidReference);
        NSString *uuidString = (__bridge NSString *)(stringReference);
        [[NSUserDefaults standardUserDefaults] setObject:uuidString forKey:[[NSBundle mainBundle] bundleIdentifier]];
        [[NSUserDefaults standardUserDefaults] synchronize];
        CFRelease(uuidReference);
        CFRelease(stringReference);
        return uuidString;
    }
}

#pragma mark
#pragma mark Image Aspect Ratio MAintainence
+(UIImage*)imageWithImage: (UIImage*) sourceImage scaledToWidth: (float) i_width scaledToHeight: (float) i_height
{
    float oldWidth = sourceImage.size.width;
    float oldHeight = sourceImage.size.height;
    float scaleFactor = i_width / oldWidth;
    float scaleFactorh = i_height / oldHeight;
    float newHeight = oldHeight * scaleFactorh;
    float newWidth = oldWidth * scaleFactor;
    
    UIGraphicsBeginImageContext(CGSizeMake(newWidth, newHeight));
    [sourceImage drawInRect:CGRectMake(0, 0, newWidth, newHeight)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}



#pragma mark
#pragma mark Auto Detect Country Code
+(NSString*) autoDetectCountryCode
{
    NSString *countryCode;
    
    CTTelephonyNetworkInfo *network_Info = [CTTelephonyNetworkInfo new];
    CTCarrier *carrier = network_Info.subscriberCellularProvider;
    NSString *isdCode = [carrier.isoCountryCode uppercaseString];
    
    NSDictionary *dictCodes = [NSDictionary dictionaryWithObjectsAndKeys:@"972", @"IL",
                               @"93", @"AF", @"355", @"AL", @"213", @"DZ", @"1", @"AS",
                               @"376", @"AD", @"244", @"AO", @"1", @"AI", @"1", @"AG",
                               @"54", @"AR", @"374", @"AM", @"297", @"AW", @"61", @"AU",
                               @"43", @"AT", @"994", @"AZ", @"1", @"BS", @"973", @"BH",
                               @"880", @"BD", @"1", @"BB", @"375", @"BY", @"32", @"BE",
                               @"501", @"BZ", @"229", @"BJ", @"1", @"BM", @"975", @"BT",
                               @"387", @"BA", @"267", @"BW", @"55", @"BR", @"246", @"IO",
                               @"359", @"BG", @"226", @"BF", @"257", @"BI", @"855", @"KH",
                               @"237", @"CM", @"1", @"CA", @"238", @"CV", @"345", @"KY",
                               @"236", @"CF", @"235", @"TD", @"56", @"CL", @"86", @"CN",
                               @"61", @"CX", @"57", @"CO", @"269", @"KM", @"242", @"CG",
                               @"682", @"CK", @"506", @"CR", @"385", @"HR", @"53", @"CU",
                               @"537", @"CY", @"420", @"CZ", @"45", @"DK", @"253", @"DJ",
                               @"1", @"DM", @"1", @"DO", @"593", @"EC", @"20", @"EG",
                               @"503", @"SV", @"240", @"GQ", @"291", @"ER", @"372", @"EE",
                               @"251", @"ET", @"298", @"FO", @"679", @"FJ", @"358", @"FI",
                               @"33", @"FR", @"594", @"GF", @"689", @"PF", @"241", @"GA",
                               @"220", @"GM", @"995", @"GE", @"49", @"DE", @"233", @"GH",
                               @"350", @"GI", @"30", @"GR", @"299", @"GL", @"1", @"GD",
                               @"590", @"GP", @"1", @"GU", @"502", @"GT", @"224", @"GN",
                               @"245", @"GW", @"595", @"GY", @"509", @"HT", @"504", @"HN",
                               @"36", @"HU", @"354", @"IS", @"91", @"IN", @"62", @"ID",
                               @"964", @"IQ", @"353", @"IE", @"972", @"IL", @"39", @"IT",
                               @"1", @"JM", @"81", @"JP", @"962", @"JO", @"77", @"KZ",
                               @"254", @"KE", @"686", @"KI", @"965", @"KW", @"996", @"KG",
                               @"371", @"LV", @"961", @"LB", @"266", @"LS", @"231", @"LR",
                               @"423", @"LI", @"370", @"LT", @"352", @"LU", @"261", @"MG",
                               @"265", @"MW", @"60", @"MY", @"960", @"MV", @"223", @"ML",
                               @"356", @"MT", @"692", @"MH", @"596", @"MQ", @"222", @"MR",
                               @"230", @"MU", @"262", @"YT", @"52", @"MX", @"377", @"MC",
                               @"976", @"MN", @"382", @"ME", @"1", @"MS", @"212", @"MA",
                               @"95", @"MM", @"264", @"NA", @"674", @"NR", @"977", @"NP",
                               @"31", @"NL", @"599", @"AN", @"687", @"NC", @"64", @"NZ",
                               @"505", @"NI", @"227", @"NE", @"234", @"NG", @"683", @"NU",
                               @"672", @"NF", @"1", @"MP", @"47", @"NO", @"968", @"OM",
                               @"92", @"PK", @"680", @"PW", @"507", @"PA", @"675", @"PG",
                               @"595", @"PY", @"51", @"PE", @"63", @"PH", @"48", @"PL",
                               @"351", @"PT", @"1", @"PR", @"974", @"QA", @"40", @"RO",
                               @"250", @"RW", @"685", @"WS", @"378", @"SM", @"966", @"SA",
                               @"221", @"SN", @"381", @"RS", @"248", @"SC", @"232", @"SL",
                               @"65", @"SG", @"421", @"SK", @"386", @"SI", @"677", @"SB",
                               @"27", @"ZA", @"500", @"GS", @"34", @"ES", @"94", @"LK",
                               @"249", @"SD", @"597", @"SR", @"268", @"SZ", @"46", @"SE",
                               @"41", @"CH", @"992", @"TJ", @"66", @"TH", @"228", @"TG",
                               @"690", @"TK", @"676", @"TO", @"1", @"TT", @"216", @"TN",
                               @"90", @"TR", @"993", @"TM", @"1", @"TC", @"688", @"TV",
                               @"256", @"UG", @"380", @"UA", @"971", @"AE", @"44", @"GB",
                               @"1", @"US", @"598", @"UY", @"998", @"UZ", @"678", @"VU",
                               @"681", @"WF", @"967", @"YE", @"260", @"ZM", @"263", @"ZW",
                               @"591", @"BO", @"673", @"BN", @"61", @"CC", @"243", @"CD",
                               @"225", @"CI", @"500", @"FK", @"44", @"GG", @"379", @"VA",
                               @"852", @"HK", @"98", @"IR", @"44", @"IM", @"44", @"JE",
                               @"850", @"KP", @"82", @"KR", @"856", @"LA", @"218", @"LY",
                               @"853", @"MO", @"389", @"MK", @"691", @"FM", @"373", @"MD",
                               @"258", @"MZ", @"970", @"PS", @"872", @"PN", @"262", @"RE",
                               @"7", @"RU", @"590", @"BL", @"290", @"SH", @"1", @"KN",
                               @"1", @"LC", @"590", @"MF", @"508", @"PM", @"1", @"VC",
                               @"239", @"ST", @"252", @"SO", @"47", @"SJ", @"963", @"SY",
                               @"886", @"TW", @"255", @"TZ", @"670", @"TL", @"58", @"VE",
                               @"84", @"VN", @"1", @"VG", @"1", @"VI", nil];
    
    NSString *simCode = [dictCodes objectForKey:isdCode];
    NSLog(@"callingCode Code is %@",simCode);
    
    if (simCode.length>0)
    {
        countryCode = simCode;
    }
    else
    {
        countryCode = @"";
    }
    
    return countryCode;
}


+(NSString*) func_GetCountryNameFromCountryCode : (NSString*)countryCode
{
    NSDictionary *codes = @{
                            @"Abkhazia"                                     : @"+7840",
                            @"Afghanistan"                                  : @"+93",
                            @"Albania"                                      : @"+355",
                            @"Algeria"                                      : @"+213",
                            @"American Samoa"                               : @"+1684",
                            @"Andorra"                                      : @"+376",
                            @"Angola"                                       : @"+244",
                            @"Anguilla"                                     : @"+1264",
                            @"Antigua and Barbuda"                          : @"+1268",
                            @"Argentina"                                    : @"+54",
                            @"Armenia"                                      : @"+374",
                            @"Aruba"                                        : @"+297",
                            @"Ascension"                                    : @"+247",
                            @"Australia"                                    : @"+61",
                            @"Australian External Territories"              : @"+672",
                            @"Austria"                                      : @"+43",
                            @"Azerbaijan"                                   : @"+994",
                            @"Bahamas"                                      : @"+1242",
                            @"Bahrain"                                      : @"+973",
                            @"Bangladesh"                                   : @"+880",
                            @"Barbados"                                     : @"+1246",
                            @"Barbuda"                                      : @"+1268",
                            @"Belarus"                                      : @"+375",
                            @"Belgium"                                      : @"+32",
                            @"Belize"                                       : @"+501",
                            @"Benin"                                        : @"+229",
                            @"Bermuda"                                      : @"+1441",
                            @"Bhutan"                                       : @"+975",
                            @"Bolivia"                                      : @"+591",
                            @"Bosnia and Herzegovina"                       : @"+387",
                            @"Botswana"                                     : @"+267",
                            @"Brazil"                                       : @"+55",
                            @"British Indian Ocean Territory"               : @"+246",
                            @"British Virgin Islands"                       : @"+1284",
                            @"Brunei"                                       : @"+673",
                            @"Bulgaria"                                     : @"+359",
                            @"Burkina Faso"                                 : @"+226",
                            @"Burundi"                                      : @"+257",
                            @"Cambodia"                                     : @"+855",
                            @"Cameroon"                                     : @"+237",
                            @"Canada"                                       : @"+1",
                            @"Cape Verde"                                   : @"+238",
                            @"Cayman Islands"                               : @"+345",
                            @"Central African Republic"                     : @"+236",
                            @"Chad"                                         : @"+235",
                            @"Chile"                                        : @"+56",
                            @"China"                                        : @"+86",
                            @"Christmas Island"                             : @"+61",
                            @"Cocos-Keeling Islands"                        : @"+61",
                            @"Colombia"                                     : @"+57",
                            @"Comoros"                                      : @"+269",
                            @"Congo"                                        : @"+242",
                            @"Congo, Dem. Rep. of (Zaire)"                  : @"+243",
                            @"Cook Islands"                                 : @"+682",
                            @"Costa Rica"                                   : @"+506",
                            @"Ivory Coast"                                  : @"+225",
                            @"Croatia"                                      : @"+385",
                            @"Cuba"                                         : @"+53",
                            @"Curacao"                                      : @"+599",
                            @"Cyprus"                                       : @"+537",
                            @"Czech Republic"                               : @"+420",
                            @"Denmark"                                      : @"+45",
                            @"Diego Garcia"                                 : @"+246",
                            @"Djibouti"                                     : @"+253",
                            @"Dominica"                                     : @"+1767",
                            @"Dominican Republic"                           : @"+1809",
                            @"Dominican Republic"                           : @"+1829",
                            @"Dominican Republic"                           : @"+1849",
                            @"East Timor"                                   : @"+670",
                            @"Easter Island"                                : @"+56",
                            @"Ecuador"                                      : @"+593",
                            @"Egypt"                                        : @"+20",
                            @"El Salvador"                                  : @"+503",
                            @"Equatorial Guinea"                            : @"+240",
                            @"Eritrea"                                      : @"+291",
                            @"Estonia"                                      : @"+372",
                            @"Ethiopia"                                     : @"+251",
                            @"Falkland Islands"                             : @"+500",
                            @"Faroe Islands"                                : @"+298",
                            @"Fiji"                                         : @"+679",
                            @"Finland"                                      : @"+358",
                            @"France"                                       : @"+33",
                            @"French Antilles"                              : @"+596",
                            @"French Guiana"                                : @"+594",
                            @"French Polynesia"                             : @"+689",
                            @"Gabon"                                        : @"+241",
                            @"Gambia"                                       : @"+220",
                            @"Georgia"                                      : @"+995",
                            @"Germany"                                      : @"+49",
                            @"Ghana"                                        : @"+233",
                            @"Gibraltar"                                    : @"+350",
                            @"Greece"                                       : @"+30",
                            @"Greenland"                                    : @"+299",
                            @"Grenada"                                      : @"+1473",
                            @"Guadeloupe"                                   : @"+590",
                            @"Guam"                                         : @"+1671",
                            @"Guatemala"                                    : @"+502",
                            @"Guinea"                                       : @"+224",
                            @"Guinea-Bissau"                                : @"+245",
                            @"Guyana"                                       : @"+595",
                            @"Haiti"                                        : @"+509",
                            @"Honduras"                                     : @"+504",
                            @"Hong Kong SAR China"                          : @"+852",
                            @"Hungary"                                      : @"+36",
                            @"Iceland"                                      : @"+354",
                            @"India"                                        : @"+91",
                            @"Indonesia"                                    : @"+62",
                            @"Iran"                                         : @"+98",
                            @"Iraq"                                         : @"+964",
                            @"Ireland"                                      : @"+353",
                            @"Israel"                                       : @"+972",
                            @"Italy"                                        : @"+39",
                            @"Jamaica"                                      : @"+1876",
                            @"Japan"                                        : @"+81",
                            @"Jordan"                                       : @"+962",
                            @"Kazakhstan"                                   : @"+77",
                            @"Kenya"                                        : @"+254",
                            @"Kiribati"                                     : @"+686",
                            @"North Korea"                                  : @"+850",
                            @"South Korea"                                  : @"+82",
                            @"Kuwait"                                       : @"+965",
                            @"Kyrgyzstan"                                   : @"+996",
                            @"Laos"                                         : @"+856",
                            @"Latvia"                                       : @"+371",
                            @"Lebanon"                                      : @"+961",
                            @"Lesotho"                                      : @"+266",
                            @"Liberia"                                      : @"+231",
                            @"Libya"                                        : @"+218",
                            @"Liechtenstein"                                : @"+423",
                            @"Lithuania"                                    : @"+370",
                            @"Luxembourg"                                   : @"+352",
                            @"Macau SAR China"                              : @"+853",
                            @"Macedonia"                                    : @"+389",
                            @"Madagascar"                                   : @"+261",
                            @"Malawi"                                       : @"+265",
                            @"Malaysia"                                     : @"+60",
                            @"Maldives"                                     : @"+960",
                            @"Mali"                                         : @"+223",
                            @"Malta"                                        : @"+356",
                            @"Marshall Islands"                             : @"+692",
                            @"Martinique"                                   : @"+596",
                            @"Mauritania"                                   : @"+222",
                            @"Mauritius"                                    : @"+230",
                            @"Mayotte"                                      : @"+262",
                            @"Mexico"                                       : @"+52",
                            @"Micronesia"                                   : @"+691",
                            @"Midway Island"                                : @"+1808",
                            @"Micronesia"                                   : @"+691",
                            @"Moldova"                                      : @"+373",
                            @"Monaco"                                       : @"+377",
                            @"Mongolia"                                     : @"+976",
                            @"Montenegro"                                   : @"+382",
                            @"Montserrat"                                   : @"+1664",
                            @"Morocco"                                      : @"+212",
                            @"Myanmar"                                      : @"+95",
                            @"Namibia"                                      : @"+264",
                            @"Nauru"                                        : @"+674",
                            @"Nepal"                                        : @"+977",
                            @"Netherlands"                                  : @"+31",
                            @"Netherlands Antilles"                         : @"+599",
                            @"Nevis"                                        : @"+1869",
                            @"New Caledonia"                                : @"+687",
                            @"New Zealand"                                  : @"+64",
                            @"Nicaragua"                                    : @"+505",
                            @"Niger"                                        : @"+227",
                            @"Nigeria"                                      : @"+234",
                            @"Niue"                                         : @"+683",
                            @"Norfolk Island"                               : @"+672",
                            @"Northern Mariana Islands"                     : @"+1670",
                            @"Norway"                                       : @"+47",
                            @"Oman"                                         : @"+968",
                            @"Pakistan"                                     : @"+92",
                            @"Palau"                                        : @"+680",
                            @"Palestinian Territory"                        : @"+970",
                            @"Panama"                                       : @"+507",
                            @"Papua New Guinea"                             : @"+675",
                            @"Paraguay"                                     : @"+595",
                            @"Peru"                                         : @"+51",
                            @"Philippines"                                  : @"+63",
                            @"Poland"                                       : @"+48",
                            @"Portugal"                                     : @"+351",
                            @"Puerto Rico"                                  : @"+1787",
                            @"Puerto Rico"                                  : @"+1939",
                            @"Qatar"                                        : @"+974",
                            @"Reunion"                                      : @"+262",
                            @"Romania"                                      : @"+40",
                            @"Russia"                                       : @"+7",
                            @"Rwanda"                                       : @"+250",
                            @"Samoa"                                        : @"+685",
                            @"San Marino"                                   : @"+378",
                            @"Saudi Arabia"                                 : @"+966",
                            @"Senegal"                                      : @"+221",
                            @"Serbia"                                       : @"+381",
                            @"Seychelles"                                   : @"+248",
                            @"Sierra Leone"                                 : @"+232",
                            @"Singapore"                                    : @"+65",
                            @"Slovakia"                                     : @"+421",
                            @"Slovenia"                                     : @"+386",
                            @"Solomon Islands"                              : @"+677",
                            @"South Africa"                                 : @"+27",
                            @"South Georgia and the South Sandwich Islands" : @"+500",
                            @"Spain"                                        : @"+34",
                            @"Sri Lanka"                                    : @"+94",
                            @"Sudan"                                        : @"+249",
                            @"Suriname"                                     : @"+597",
                            @"Swaziland"                                    : @"+268",
                            @"Sweden"                                       : @"+46",
                            @"Switzerland"                                  : @"+41",
                            @"Syria"                                        : @"+963",
                            @"Taiwan"                                       : @"+886",
                            @"Tajikistan"                                   : @"+992",
                            @"Tanzania"                                     : @"+255",
                            @"Thailand"                                     : @"+66",
                            @"Timor Leste"                                  : @"+670",
                            @"Togo"                                         : @"+228",
                            @"Tokelau"                                      : @"+690",
                            @"Tonga"                                        : @"+676",
                            @"Trinidad and Tobago"                          : @"+1868",
                            @"Tunisia"                                      : @"+216",
                            @"Turkey"                                       : @"+90",
                            @"Turkmenistan"                                 : @"+993",
                            @"Turks and Caicos Islands"                     : @"+1649",
                            @"Tuvalu"                                       : @"+688",
                            @"Uganda"                                       : @"+256",
                            @"Ukraine"                                      : @"+380",
                            @"United Arab Emirates"                         : @"+971",
                            @"United Kingdom"                               : @"+44",
                            @"United States"                                : @"+1",
                            @"Uruguay"                                      : @"+598",
                            @"U.S. Virgin Islands"                          : @"+1340",
                            @"Uzbekistan"                                   : @"+998",
                            @"Vanuatu"                                      : @"+678",
                            @"Venezuela"                                    : @"+58",
                            @"Vietnam"                                      : @"+84",
                            @"Wake Island"                                  : @"+1808",
                            @"Wallis and Futuna"                            : @"+681",
                            @"Yemen"                                        : @"+967",
                            @"Zambia"                                       : @"+260",
                            @"Zanzibar"                                     : @"+255",
                            @"Zimbabwe"                                     : @"+263"
                            };
    
    

    
    NSArray *temp = [codes allKeysForObject:countryCode];
    NSString *key = [temp lastObject];
    return key;
}

+(NSMutableArray*)func_GetAllCountries_Name
{
    NSDictionary *codes = @{
                            @"Abkhazia"                                     : @"+7840",
                            @"Afghanistan"                                  : @"+93",
                            @"Albania"                                      : @"+355",
                            @"Algeria"                                      : @"+213",
                            @"American Samoa"                               : @"+1684",
                            @"Andorra"                                      : @"+376",
                            @"Angola"                                       : @"+244",
                            @"Anguilla"                                     : @"+1264",
                            @"Antigua and Barbuda"                          : @"+1268",
                            @"Argentina"                                    : @"+54",
                            @"Armenia"                                      : @"+374",
                            @"Aruba"                                        : @"+297",
                            @"Ascension"                                    : @"+247",
                            @"Australia"                                    : @"+61",
                            @"Australian External Territories"              : @"+672",
                            @"Austria"                                      : @"+43",
                            @"Azerbaijan"                                   : @"+994",
                            @"Bahamas"                                      : @"+1242",
                            @"Bahrain"                                      : @"+973",
                            @"Bangladesh"                                   : @"+880",
                            @"Barbados"                                     : @"+1246",
                            @"Barbuda"                                      : @"+1268",
                            @"Belarus"                                      : @"+375",
                            @"Belgium"                                      : @"+32",
                            @"Belize"                                       : @"+501",
                            @"Benin"                                        : @"+229",
                            @"Bermuda"                                      : @"+1441",
                            @"Bhutan"                                       : @"+975",
                            @"Bolivia"                                      : @"+591",
                            @"Bosnia and Herzegovina"                       : @"+387",
                            @"Botswana"                                     : @"+267",
                            @"Brazil"                                       : @"+55",
                            @"British Indian Ocean Territory"               : @"+246",
                            @"British Virgin Islands"                       : @"+1284",
                            @"Brunei"                                       : @"+673",
                            @"Bulgaria"                                     : @"+359",
                            @"Burkina Faso"                                 : @"+226",
                            @"Burundi"                                      : @"+257",
                            @"Cambodia"                                     : @"+855",
                            @"Cameroon"                                     : @"+237",
                            @"Canada"                                       : @"+1",
                            @"Cape Verde"                                   : @"+238",
                            @"Cayman Islands"                               : @"+345",
                            @"Central African Republic"                     : @"+236",
                            @"Chad"                                         : @"+235",
                            @"Chile"                                        : @"+56",
                            @"China"                                        : @"+86",
                            @"Christmas Island"                             : @"+61",
                            @"Cocos-Keeling Islands"                        : @"+61",
                            @"Colombia"                                     : @"+57",
                            @"Comoros"                                      : @"+269",
                            @"Congo"                                        : @"+242",
                            @"Congo, Dem. Rep. of (Zaire)"                  : @"+243",
                            @"Cook Islands"                                 : @"+682",
                            @"Costa Rica"                                   : @"+506",
                            @"Ivory Coast"                                  : @"+225",
                            @"Croatia"                                      : @"+385",
                            @"Cuba"                                         : @"+53",
                            @"Curacao"                                      : @"+599",
                            @"Cyprus"                                       : @"+537",
                            @"Czech Republic"                               : @"+420",
                            @"Denmark"                                      : @"+45",
                            @"Diego Garcia"                                 : @"+246",
                            @"Djibouti"                                     : @"+253",
                            @"Dominica"                                     : @"+1767",
                            @"Dominican Republic"                           : @"+1809",
                            @"Dominican Republic"                           : @"+1829",
                            @"Dominican Republic"                           : @"+1849",
                            @"East Timor"                                   : @"+670",
                            @"Easter Island"                                : @"+56",
                            @"Ecuador"                                      : @"+593",
                            @"Egypt"                                        : @"+20",
                            @"El Salvador"                                  : @"+503",
                            @"Equatorial Guinea"                            : @"+240",
                            @"Eritrea"                                      : @"+291",
                            @"Estonia"                                      : @"+372",
                            @"Ethiopia"                                     : @"+251",
                            @"Falkland Islands"                             : @"+500",
                            @"Faroe Islands"                                : @"+298",
                            @"Fiji"                                         : @"+679",
                            @"Finland"                                      : @"+358",
                            @"France"                                       : @"+33",
                            @"French Antilles"                              : @"+596",
                            @"French Guiana"                                : @"+594",
                            @"French Polynesia"                             : @"+689",
                            @"Gabon"                                        : @"+241",
                            @"Gambia"                                       : @"+220",
                            @"Georgia"                                      : @"+995",
                            @"Germany"                                      : @"+49",
                            @"Ghana"                                        : @"+233",
                            @"Gibraltar"                                    : @"+350",
                            @"Greece"                                       : @"+30",
                            @"Greenland"                                    : @"+299",
                            @"Grenada"                                      : @"+1473",
                            @"Guadeloupe"                                   : @"+590",
                            @"Guam"                                         : @"+1671",
                            @"Guatemala"                                    : @"+502",
                            @"Guinea"                                       : @"+224",
                            @"Guinea-Bissau"                                : @"+245",
                            @"Guyana"                                       : @"+595",
                            @"Haiti"                                        : @"+509",
                            @"Honduras"                                     : @"+504",
                            @"Hong Kong SAR China"                          : @"+852",
                            @"Hungary"                                      : @"+36",
                            @"Iceland"                                      : @"+354",
                            @"India"                                        : @"+91",
                            @"Indonesia"                                    : @"+62",
                            @"Iran"                                         : @"+98",
                            @"Iraq"                                         : @"+964",
                            @"Ireland"                                      : @"+353",
                            @"Israel"                                       : @"+972",
                            @"Italy"                                        : @"+39",
                            @"Jamaica"                                      : @"+1876",
                            @"Japan"                                        : @"+81",
                            @"Jordan"                                       : @"+962",
                            @"Kazakhstan"                                   : @"+77",
                            @"Kenya"                                        : @"+254",
                            @"Kiribati"                                     : @"+686",
                            @"North Korea"                                  : @"+850",
                            @"South Korea"                                  : @"+82",
                            @"Kuwait"                                       : @"+965",
                            @"Kyrgyzstan"                                   : @"+996",
                            @"Laos"                                         : @"+856",
                            @"Latvia"                                       : @"+371",
                            @"Lebanon"                                      : @"+961",
                            @"Lesotho"                                      : @"+266",
                            @"Liberia"                                      : @"+231",
                            @"Libya"                                        : @"+218",
                            @"Liechtenstein"                                : @"+423",
                            @"Lithuania"                                    : @"+370",
                            @"Luxembourg"                                   : @"+352",
                            @"Macau SAR China"                              : @"+853",
                            @"Macedonia"                                    : @"+389",
                            @"Madagascar"                                   : @"+261",
                            @"Malawi"                                       : @"+265",
                            @"Malaysia"                                     : @"+60",
                            @"Maldives"                                     : @"+960",
                            @"Mali"                                         : @"+223",
                            @"Malta"                                        : @"+356",
                            @"Marshall Islands"                             : @"+692",
                            @"Martinique"                                   : @"+596",
                            @"Mauritania"                                   : @"+222",
                            @"Mauritius"                                    : @"+230",
                            @"Mayotte"                                      : @"+262",
                            @"Mexico"                                       : @"+52",
                            @"Micronesia"                                   : @"+691",
                            @"Midway Island"                                : @"+1808",
                            @"Micronesia"                                   : @"+691",
                            @"Moldova"                                      : @"+373",
                            @"Monaco"                                       : @"+377",
                            @"Mongolia"                                     : @"+976",
                            @"Montenegro"                                   : @"+382",
                            @"Montserrat"                                   : @"+1664",
                            @"Morocco"                                      : @"+212",
                            @"Myanmar"                                      : @"+95",
                            @"Namibia"                                      : @"+264",
                            @"Nauru"                                        : @"+674",
                            @"Nepal"                                        : @"+977",
                            @"Netherlands"                                  : @"+31",
                            @"Netherlands Antilles"                         : @"+599",
                            @"Nevis"                                        : @"+1869",
                            @"New Caledonia"                                : @"+687",
                            @"New Zealand"                                  : @"+64",
                            @"Nicaragua"                                    : @"+505",
                            @"Niger"                                        : @"+227",
                            @"Nigeria"                                      : @"+234",
                            @"Niue"                                         : @"+683",
                            @"Norfolk Island"                               : @"+672",
                            @"Northern Mariana Islands"                     : @"+1670",
                            @"Norway"                                       : @"+47",
                            @"Oman"                                         : @"+968",
                            @"Pakistan"                                     : @"+92",
                            @"Palau"                                        : @"+680",
                            @"Palestinian Territory"                        : @"+970",
                            @"Panama"                                       : @"+507",
                            @"Papua New Guinea"                             : @"+675",
                            @"Paraguay"                                     : @"+595",
                            @"Peru"                                         : @"+51",
                            @"Philippines"                                  : @"+63",
                            @"Poland"                                       : @"+48",
                            @"Portugal"                                     : @"+351",
                            @"Puerto Rico"                                  : @"+1787",
                            @"Puerto Rico"                                  : @"+1939",
                            @"Qatar"                                        : @"+974",
                            @"Reunion"                                      : @"+262",
                            @"Romania"                                      : @"+40",
                            @"Russia"                                       : @"+7",
                            @"Rwanda"                                       : @"+250",
                            @"Samoa"                                        : @"+685",
                            @"San Marino"                                   : @"+378",
                            @"Saudi Arabia"                                 : @"+966",
                            @"Senegal"                                      : @"+221",
                            @"Serbia"                                       : @"+381",
                            @"Seychelles"                                   : @"+248",
                            @"Sierra Leone"                                 : @"+232",
                            @"Singapore"                                    : @"+65",
                            @"Slovakia"                                     : @"+421",
                            @"Slovenia"                                     : @"+386",
                            @"Solomon Islands"                              : @"+677",
                            @"South Africa"                                 : @"+27",
                            @"South Georgia and the South Sandwich Islands" : @"+500",
                            @"Spain"                                        : @"+34",
                            @"Sri Lanka"                                    : @"+94",
                            @"Sudan"                                        : @"+249",
                            @"Suriname"                                     : @"+597",
                            @"Swaziland"                                    : @"+268",
                            @"Sweden"                                       : @"+46",
                            @"Switzerland"                                  : @"+41",
                            @"Syria"                                        : @"+963",
                            @"Taiwan"                                       : @"+886",
                            @"Tajikistan"                                   : @"+992",
                            @"Tanzania"                                     : @"+255",
                            @"Thailand"                                     : @"+66",
                            @"Timor Leste"                                  : @"+670",
                            @"Togo"                                         : @"+228",
                            @"Tokelau"                                      : @"+690",
                            @"Tonga"                                        : @"+676",
                            @"Trinidad and Tobago"                          : @"+1868",
                            @"Tunisia"                                      : @"+216",
                            @"Turkey"                                       : @"+90",
                            @"Turkmenistan"                                 : @"+993",
                            @"Turks and Caicos Islands"                     : @"+1649",
                            @"Tuvalu"                                       : @"+688",
                            @"Uganda"                                       : @"+256",
                            @"Ukraine"                                      : @"+380",
                            @"United Arab Emirates"                         : @"+971",
                            @"United Kingdom"                               : @"+44",
                            @"United States"                                : @"+1",
                            @"Uruguay"                                      : @"+598",
                            @"U.S. Virgin Islands"                          : @"+1340",
                            @"Uzbekistan"                                   : @"+998",
                            @"Vanuatu"                                      : @"+678",
                            @"Venezuela"                                    : @"+58",
                            @"Vietnam"                                      : @"+84",
                            @"Wake Island"                                  : @"+1808",
                            @"Wallis and Futuna"                            : @"+681",
                            @"Yemen"                                        : @"+967",
                            @"Zambia"                                       : @"+260",
                            @"Zanzibar"                                     : @"+255",
                            @"Zimbabwe"                                     : @"+263"
                            };
    
    NSMutableArray *finalCountry = [[NSMutableArray alloc]init];
    NSMutableArray *finalCode = [[NSMutableArray alloc]init];
    NSArray *allCountriesArray = [[NSArray alloc]init];
    allCountriesArray = [codes allKeys];

    
    for (int i=0; i<allCountriesArray.count; i++)
    {
        [finalCode addObject:[codes valueForKey:[allCountriesArray objectAtIndex:i]]];
        [finalCountry addObject:[allCountriesArray objectAtIndex:i]];
    }

    
    
    NSArray *abc12 =  [[NSArray alloc]initWithArray:finalCountry];
    NSArray *sortedArray111 = [abc12 sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    
    [finalCountry removeAllObjects];
    finalCountry = [sortedArray111 mutableCopy];
    [finalCode removeAllObjects];
    
    for (int i=0; i<finalCountry.count; i++)
    {
        [finalCode addObject:[codes valueForKey:[finalCountry objectAtIndex:i]]];
    }
    
    NSMutableArray *temp_finalCodeArray = [[NSMutableArray alloc]init];
    NSMutableArray *temp_finalCountryArray = [[NSMutableArray alloc]init];
    temp_finalCodeArray = [finalCode mutableCopy];
    temp_finalCountryArray = [finalCountry mutableCopy];
    
    return temp_finalCountryArray;
}


+(NSMutableArray*)func_GetAllCountries_Code
{
    NSDictionary *codes = @{
                            @"Abkhazia"                                     : @"+7840",
                            @"Afghanistan"                                  : @"+93",
                            @"Albania"                                      : @"+355",
                            @"Algeria"                                      : @"+213",
                            @"American Samoa"                               : @"+1684",
                            @"Andorra"                                      : @"+376",
                            @"Angola"                                       : @"+244",
                            @"Anguilla"                                     : @"+1264",
                            @"Antigua and Barbuda"                          : @"+1268",
                            @"Argentina"                                    : @"+54",
                            @"Armenia"                                      : @"+374",
                            @"Aruba"                                        : @"+297",
                            @"Ascension"                                    : @"+247",
                            @"Australia"                                    : @"+61",
                            @"Australian External Territories"              : @"+672",
                            @"Austria"                                      : @"+43",
                            @"Azerbaijan"                                   : @"+994",
                            @"Bahamas"                                      : @"+1242",
                            @"Bahrain"                                      : @"+973",
                            @"Bangladesh"                                   : @"+880",
                            @"Barbados"                                     : @"+1246",
                            @"Barbuda"                                      : @"+1268",
                            @"Belarus"                                      : @"+375",
                            @"Belgium"                                      : @"+32",
                            @"Belize"                                       : @"+501",
                            @"Benin"                                        : @"+229",
                            @"Bermuda"                                      : @"+1441",
                            @"Bhutan"                                       : @"+975",
                            @"Bolivia"                                      : @"+591",
                            @"Bosnia and Herzegovina"                       : @"+387",
                            @"Botswana"                                     : @"+267",
                            @"Brazil"                                       : @"+55",
                            @"British Indian Ocean Territory"               : @"+246",
                            @"British Virgin Islands"                       : @"+1284",
                            @"Brunei"                                       : @"+673",
                            @"Bulgaria"                                     : @"+359",
                            @"Burkina Faso"                                 : @"+226",
                            @"Burundi"                                      : @"+257",
                            @"Cambodia"                                     : @"+855",
                            @"Cameroon"                                     : @"+237",
                            @"Canada"                                       : @"+1",
                            @"Cape Verde"                                   : @"+238",
                            @"Cayman Islands"                               : @"+345",
                            @"Central African Republic"                     : @"+236",
                            @"Chad"                                         : @"+235",
                            @"Chile"                                        : @"+56",
                            @"China"                                        : @"+86",
                            @"Christmas Island"                             : @"+61",
                            @"Cocos-Keeling Islands"                        : @"+61",
                            @"Colombia"                                     : @"+57",
                            @"Comoros"                                      : @"+269",
                            @"Congo"                                        : @"+242",
                            @"Congo, Dem. Rep. of (Zaire)"                  : @"+243",
                            @"Cook Islands"                                 : @"+682",
                            @"Costa Rica"                                   : @"+506",
                            @"Ivory Coast"                                  : @"+225",
                            @"Croatia"                                      : @"+385",
                            @"Cuba"                                         : @"+53",
                            @"Curacao"                                      : @"+599",
                            @"Cyprus"                                       : @"+537",
                            @"Czech Republic"                               : @"+420",
                            @"Denmark"                                      : @"+45",
                            @"Diego Garcia"                                 : @"+246",
                            @"Djibouti"                                     : @"+253",
                            @"Dominica"                                     : @"+1767",
                            @"Dominican Republic"                           : @"+1809",
                            @"Dominican Republic"                           : @"+1829",
                            @"Dominican Republic"                           : @"+1849",
                            @"East Timor"                                   : @"+670",
                            @"Easter Island"                                : @"+56",
                            @"Ecuador"                                      : @"+593",
                            @"Egypt"                                        : @"+20",
                            @"El Salvador"                                  : @"+503",
                            @"Equatorial Guinea"                            : @"+240",
                            @"Eritrea"                                      : @"+291",
                            @"Estonia"                                      : @"+372",
                            @"Ethiopia"                                     : @"+251",
                            @"Falkland Islands"                             : @"+500",
                            @"Faroe Islands"                                : @"+298",
                            @"Fiji"                                         : @"+679",
                            @"Finland"                                      : @"+358",
                            @"France"                                       : @"+33",
                            @"French Antilles"                              : @"+596",
                            @"French Guiana"                                : @"+594",
                            @"French Polynesia"                             : @"+689",
                            @"Gabon"                                        : @"+241",
                            @"Gambia"                                       : @"+220",
                            @"Georgia"                                      : @"+995",
                            @"Germany"                                      : @"+49",
                            @"Ghana"                                        : @"+233",
                            @"Gibraltar"                                    : @"+350",
                            @"Greece"                                       : @"+30",
                            @"Greenland"                                    : @"+299",
                            @"Grenada"                                      : @"+1473",
                            @"Guadeloupe"                                   : @"+590",
                            @"Guam"                                         : @"+1671",
                            @"Guatemala"                                    : @"+502",
                            @"Guinea"                                       : @"+224",
                            @"Guinea-Bissau"                                : @"+245",
                            @"Guyana"                                       : @"+595",
                            @"Haiti"                                        : @"+509",
                            @"Honduras"                                     : @"+504",
                            @"Hong Kong SAR China"                          : @"+852",
                            @"Hungary"                                      : @"+36",
                            @"Iceland"                                      : @"+354",
                            @"India"                                        : @"+91",
                            @"Indonesia"                                    : @"+62",
                            @"Iran"                                         : @"+98",
                            @"Iraq"                                         : @"+964",
                            @"Ireland"                                      : @"+353",
                            @"Israel"                                       : @"+972",
                            @"Italy"                                        : @"+39",
                            @"Jamaica"                                      : @"+1876",
                            @"Japan"                                        : @"+81",
                            @"Jordan"                                       : @"+962",
                            @"Kazakhstan"                                   : @"+77",
                            @"Kenya"                                        : @"+254",
                            @"Kiribati"                                     : @"+686",
                            @"North Korea"                                  : @"+850",
                            @"South Korea"                                  : @"+82",
                            @"Kuwait"                                       : @"+965",
                            @"Kyrgyzstan"                                   : @"+996",
                            @"Laos"                                         : @"+856",
                            @"Latvia"                                       : @"+371",
                            @"Lebanon"                                      : @"+961",
                            @"Lesotho"                                      : @"+266",
                            @"Liberia"                                      : @"+231",
                            @"Libya"                                        : @"+218",
                            @"Liechtenstein"                                : @"+423",
                            @"Lithuania"                                    : @"+370",
                            @"Luxembourg"                                   : @"+352",
                            @"Macau SAR China"                              : @"+853",
                            @"Macedonia"                                    : @"+389",
                            @"Madagascar"                                   : @"+261",
                            @"Malawi"                                       : @"+265",
                            @"Malaysia"                                     : @"+60",
                            @"Maldives"                                     : @"+960",
                            @"Mali"                                         : @"+223",
                            @"Malta"                                        : @"+356",
                            @"Marshall Islands"                             : @"+692",
                            @"Martinique"                                   : @"+596",
                            @"Mauritania"                                   : @"+222",
                            @"Mauritius"                                    : @"+230",
                            @"Mayotte"                                      : @"+262",
                            @"Mexico"                                       : @"+52",
                            @"Micronesia"                                   : @"+691",
                            @"Midway Island"                                : @"+1808",
                            @"Micronesia"                                   : @"+691",
                            @"Moldova"                                      : @"+373",
                            @"Monaco"                                       : @"+377",
                            @"Mongolia"                                     : @"+976",
                            @"Montenegro"                                   : @"+382",
                            @"Montserrat"                                   : @"+1664",
                            @"Morocco"                                      : @"+212",
                            @"Myanmar"                                      : @"+95",
                            @"Namibia"                                      : @"+264",
                            @"Nauru"                                        : @"+674",
                            @"Nepal"                                        : @"+977",
                            @"Netherlands"                                  : @"+31",
                            @"Netherlands Antilles"                         : @"+599",
                            @"Nevis"                                        : @"+1869",
                            @"New Caledonia"                                : @"+687",
                            @"New Zealand"                                  : @"+64",
                            @"Nicaragua"                                    : @"+505",
                            @"Niger"                                        : @"+227",
                            @"Nigeria"                                      : @"+234",
                            @"Niue"                                         : @"+683",
                            @"Norfolk Island"                               : @"+672",
                            @"Northern Mariana Islands"                     : @"+1670",
                            @"Norway"                                       : @"+47",
                            @"Oman"                                         : @"+968",
                            @"Pakistan"                                     : @"+92",
                            @"Palau"                                        : @"+680",
                            @"Palestinian Territory"                        : @"+970",
                            @"Panama"                                       : @"+507",
                            @"Papua New Guinea"                             : @"+675",
                            @"Paraguay"                                     : @"+595",
                            @"Peru"                                         : @"+51",
                            @"Philippines"                                  : @"+63",
                            @"Poland"                                       : @"+48",
                            @"Portugal"                                     : @"+351",
                            @"Puerto Rico"                                  : @"+1787",
                            @"Puerto Rico"                                  : @"+1939",
                            @"Qatar"                                        : @"+974",
                            @"Reunion"                                      : @"+262",
                            @"Romania"                                      : @"+40",
                            @"Russia"                                       : @"+7",
                            @"Rwanda"                                       : @"+250",
                            @"Samoa"                                        : @"+685",
                            @"San Marino"                                   : @"+378",
                            @"Saudi Arabia"                                 : @"+966",
                            @"Senegal"                                      : @"+221",
                            @"Serbia"                                       : @"+381",
                            @"Seychelles"                                   : @"+248",
                            @"Sierra Leone"                                 : @"+232",
                            @"Singapore"                                    : @"+65",
                            @"Slovakia"                                     : @"+421",
                            @"Slovenia"                                     : @"+386",
                            @"Solomon Islands"                              : @"+677",
                            @"South Africa"                                 : @"+27",
                            @"South Georgia and the South Sandwich Islands" : @"+500",
                            @"Spain"                                        : @"+34",
                            @"Sri Lanka"                                    : @"+94",
                            @"Sudan"                                        : @"+249",
                            @"Suriname"                                     : @"+597",
                            @"Swaziland"                                    : @"+268",
                            @"Sweden"                                       : @"+46",
                            @"Switzerland"                                  : @"+41",
                            @"Syria"                                        : @"+963",
                            @"Taiwan"                                       : @"+886",
                            @"Tajikistan"                                   : @"+992",
                            @"Tanzania"                                     : @"+255",
                            @"Thailand"                                     : @"+66",
                            @"Timor Leste"                                  : @"+670",
                            @"Togo"                                         : @"+228",
                            @"Tokelau"                                      : @"+690",
                            @"Tonga"                                        : @"+676",
                            @"Trinidad and Tobago"                          : @"+1868",
                            @"Tunisia"                                      : @"+216",
                            @"Turkey"                                       : @"+90",
                            @"Turkmenistan"                                 : @"+993",
                            @"Turks and Caicos Islands"                     : @"+1649",
                            @"Tuvalu"                                       : @"+688",
                            @"Uganda"                                       : @"+256",
                            @"Ukraine"                                      : @"+380",
                            @"United Arab Emirates"                         : @"+971",
                            @"United Kingdom"                               : @"+44",
                            @"United States"                                : @"+1",
                            @"Uruguay"                                      : @"+598",
                            @"U.S. Virgin Islands"                          : @"+1340",
                            @"Uzbekistan"                                   : @"+998",
                            @"Vanuatu"                                      : @"+678",
                            @"Venezuela"                                    : @"+58",
                            @"Vietnam"                                      : @"+84",
                            @"Wake Island"                                  : @"+1808",
                            @"Wallis and Futuna"                            : @"+681",
                            @"Yemen"                                        : @"+967",
                            @"Zambia"                                       : @"+260",
                            @"Zanzibar"                                     : @"+255",
                            @"Zimbabwe"                                     : @"+263"
                            };
    
    NSMutableArray *finalCountry = [[NSMutableArray alloc]init];
    NSMutableArray *finalCode = [[NSMutableArray alloc]init];
    NSArray *allCountriesArray = [[NSArray alloc]init];
    allCountriesArray = [codes allKeys];
    
    
    for (int i=0; i<allCountriesArray.count; i++)
    {
        [finalCode addObject:[codes valueForKey:[allCountriesArray objectAtIndex:i]]];
        [finalCountry addObject:[allCountriesArray objectAtIndex:i]];
    }
    
    
    
    NSArray *abc12 =  [[NSArray alloc]initWithArray:finalCountry];
    NSArray *sortedArray111 = [abc12 sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    
    [finalCountry removeAllObjects];
    finalCountry = [sortedArray111 mutableCopy];
    [finalCode removeAllObjects];
    
    for (int i=0; i<finalCountry.count; i++)
    {
        [finalCode addObject:[codes valueForKey:[finalCountry objectAtIndex:i]]];
    }
    
    NSMutableArray *temp_finalCodeArray = [[NSMutableArray alloc]init];
    NSMutableArray *temp_finalCountryArray = [[NSMutableArray alloc]init];
    temp_finalCodeArray = [finalCode mutableCopy];
    temp_finalCountryArray = [finalCountry mutableCopy];
    return temp_finalCodeArray;
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 54545450 && buttonIndex == 1)
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }
}

#pragma mark
#pragma mark FetchAllContactsFromUserPhoneBook
+(NSMutableDictionary*) FetchAllContactsFromUserPhoneBook
{
    
    NSMutableArray *returnArray = [[NSMutableArray alloc]init];
    
    NSMutableArray *myTestingArray = [[NSMutableArray alloc]init];
    NSString *ankitStrring;
    NSString *addressBookNum;
    NSDictionary *myDict;
    
    
    @try
    {
        ABAddressBookRef addressBookRef = ABAddressBookCreateWithOptions(NULL, NULL);
        
        if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined)
        {
            ABAddressBookRequestAccessWithCompletion(addressBookRef, ^(bool granted, CFErrorRef error)
            {
                // ABAddressBookRef addressBook = ABAddressBookCreate( );
                NSLog(@"PERMISSION NAHI HAI MUJHE");
                
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"You need to approve access to your contact book. Please go to settings and do so." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
                alert.tag = 54545450;
                [alert show];
            });
        }
        
         else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusRestricted || ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusDenied)
         {
             UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"You need to approve access to your contact book. Please go to settings and do so." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
             alert.tag = 54545450;
             [alert show];
         }
        
        else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized)
        {
            
            CFErrorRef *error = NULL;
            ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, error);
            CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(addressBook);
            
            
            CFMutableArrayRef peopleMutable = CFArrayCreateMutableCopy(kCFAllocatorDefault,
                                                                       CFArrayGetCount(allPeople),
                                                                       allPeople);
            
            CFArraySortValues(peopleMutable,
                              CFRangeMake(0, CFArrayGetCount(peopleMutable)),
                              (CFComparatorFunction) ABPersonComparePeopleByName,
                              kABPersonSortByFirstName);
            
            
            for(int i = 0; i < CFArrayGetCount(peopleMutable); i++)
            {
                ABRecordRef person = CFArrayGetValueAtIndex( peopleMutable, i );
                ABMultiValueRef phoneNumbers = ABRecordCopyValue(person, kABPersonPhoneProperty);
                NSString *firstName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
                NSString *lastName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
                
                // KISI KA NAME HAI LEKIN NUMBER NAHI HAI
                
                if( (firstName || lastName)    && (!ABMultiValueGetCount(phoneNumbers))   )
                {
                    NSMutableArray *tempEmailArray = [[NSMutableArray alloc]init];
                    NSString *firstName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
                    NSString *lastName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
                    NSString *emailID = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonEmailProperty));
                    NSData  *imgData = (__bridge_transfer NSData *) ABPersonCopyImageDataWithFormat(person, kABPersonImageFormatThumbnail);
                    UIImage *personImage;
                    
                    firstName =  [firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    lastName =  [lastName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    
                    if (imgData.length>0)
                    {
                        personImage = [UIImage imageWithData:imgData];
                        imgData = nil;
                    }
                    else
                    {
                        personImage = [UIImage imageNamed:@"Default-480h.png"];
                    }
                    
                    for (CFIndex i = 0; i < ABMultiValueGetCount((__bridge ABMultiValueRef)(emailID)); i++)
                    {
                        NSString *email = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(CFBridgingRetain(emailID), i);
                        [tempEmailArray addObject:email];
                    }
                    
                    if (!firstName)
                    {
                        firstName = @"";
                    }
                    if (!lastName)
                    {
                        lastName = @"";
                    }
                    
                    NSMutableString *asciiCharacters = [NSMutableString string];
                    for (NSInteger i = 32; i < 127; i++)
                    {
                        [asciiCharacters appendFormat:@"%c", (int)i];
                    }
                    
                    NSCharacterSet *nonAsciiCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:asciiCharacters] invertedSet];
                    firstName = [[firstName componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                    lastName = [[lastName componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                    
                    if (!ABMultiValueGetCount(phoneNumbers))         // matlab koi phone number nahi hai, sirf name hai
                    {
                        NSString *phoneNumber1 = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(phoneNumbers, i);
                        phoneNumber1 = @"";
                        phoneNumber1 = [[phoneNumber1 componentsSeparatedByCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]] componentsJoinedByString:@""];
                        
                        firstName = [NSString stringWithFormat:@"%@ %@",firstName,lastName];
                        firstName =  [firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                        
                        NSArray *myArray = [[NSArray alloc]init];
                        myDict = [[NSDictionary alloc]initWithObjectsAndKeys:
                                  myArray,@"number",
                                  firstName,@"name",
                                  tempEmailArray,@"email",
                                  personImage,@"userImage",
                                  nil];
                    }
                    
                    if ([[myDict valueForKey:@"name"]length]==0 && [[myDict valueForKey:@"number"]count]==0)
                    {
                        
                    }
                    else
                    {
                        [myTestingArray addObject:myDict];
                    }
                }
                
                // KISI KA NUMBER HAI LEKIN NAME NAHI HAI
                
                else if( (ABMultiValueGetCount(phoneNumbers)) &&    (!firstName && !lastName)  )
                {
                    NSMutableArray *temp = [[NSMutableArray alloc]init];
                    NSMutableArray *tempEmailArray = [[NSMutableArray alloc]init];
                    
                    
                    NSString *firstName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
                    NSString *lastName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
                    
                    firstName =  [firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    lastName =  [lastName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    
                    if (!firstName)
                    {
                        firstName = @"";
                    }
                    if (!lastName)
                    {
                        lastName = @"";
                    }
                    
                    NSMutableString *asciiCharacters = [NSMutableString string];
                    for (NSInteger i = 32; i < 127; i++)
                    {
                        [asciiCharacters appendFormat:@"%c", (int)i];
                    }
                    NSCharacterSet *nonAsciiCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:asciiCharacters] invertedSet];
                    firstName = [[firstName componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                    lastName = [[lastName componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                    firstName = [NSString stringWithFormat:@"%@ %@",firstName,lastName];
                    firstName =  [firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    
                    NSString *emailID = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonEmailProperty));
                    for (CFIndex i = 0; i < ABMultiValueGetCount((__bridge ABMultiValueRef)(emailID)); i++)
                    {
                        NSString *email = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(CFBridgingRetain(emailID), i);
                        [tempEmailArray addObject:email];
                    }
                    
                    // user Image
                    NSData  *imgData = (__bridge_transfer NSData *) ABPersonCopyImageDataWithFormat(person, kABPersonImageFormatThumbnail);
                    UIImage *personImage;
                    
                    if (imgData.length>0)
                    {
                        personImage = [UIImage imageWithData:imgData];
                        imgData = nil;
                    }
                    else
                    {
                        personImage = [UIImage imageNamed:@"Default-480h.png"];
                    }
                    
                    
                    for (CFIndex i = 0; i < ABMultiValueGetCount(phoneNumbers); i++)
                    {
                        if (!firstName)
                        {
                            firstName = @"";
                        }
                        if (!lastName)
                        {
                            lastName = @"";
                        }
                        
                        // FETCH PHONE NUMBER
                        
                        NSString *phoneNumber1 = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(phoneNumbers, i);
                        
                        while (([phoneNumber1 rangeOfString:@"("].location != NSNotFound) || ([phoneNumber1 rangeOfString:@")"].location != NSNotFound)   || ([phoneNumber1 rangeOfString:@" "].location != NSNotFound) || ([phoneNumber1 rangeOfString:@"-"].location != NSNotFound)   || ([phoneNumber1 rangeOfString:@","].location != NSNotFound)  || ([phoneNumber1 rangeOfString:@"*"].location != NSNotFound)  || ([phoneNumber1 rangeOfString:@"#"].location != NSNotFound)  ||  ([phoneNumber1 rangeOfString:@"."].location != NSNotFound)       )
                        {
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"(" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@")" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@" " withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"-" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"," withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"*" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"#" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"." withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                            phoneNumber1 =  [phoneNumber1 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                        }
                        
                        NSMutableString *asciiCharacters = [NSMutableString string];
                        for (NSInteger i = 32; i < 127; i++)
                        {
                            [asciiCharacters appendFormat:@"%c", (int)i];
                        }
                        NSCharacterSet *nonAsciiCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:asciiCharacters] invertedSet];
                        phoneNumber1 = [[phoneNumber1 componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                        
                        
                        ankitStrring = nil;
                        ankitStrring = phoneNumber1;
                        phoneNumber1 = [[phoneNumber1 componentsSeparatedByCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]] componentsJoinedByString:@""];
                        
                        if ([ankitStrring hasPrefix:@"+"])
                        {
                            phoneNumber1 =  [@"+" stringByAppendingString:phoneNumber1];
                        }
                        
                        [temp addObject:phoneNumber1];
                    }
                    
                    firstName = @"";
                    NSDictionary *myDictionary = [[NSDictionary alloc]initWithObjectsAndKeys:
                                                  temp,@"number",
                                                  firstName,@"name",
                                                  tempEmailArray,@"email",
                                                  personImage,@"userImage",
                                                  nil];
                    
                    //NSLog(@"myDictionary is %@",myDictionary);
                    [myTestingArray addObject:myDictionary];
                }
                
                // NUMBER BHI HAI OR NAME BHI
                else if( (ABMultiValueGetCount(phoneNumbers)) &&    (firstName || lastName)  )
                {
                    NSMutableArray *temp = [[NSMutableArray alloc]init];
                    NSMutableArray *tempEmailArray = [[NSMutableArray alloc]init];
                    
                    NSString *firstName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
                    NSString *lastName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
                    NSString *emailID = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonEmailProperty));
                    
                    firstName =  [firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    lastName =  [lastName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    
                    
                    for (CFIndex i = 0; i < ABMultiValueGetCount((__bridge ABMultiValueRef)(emailID)); i++)
                    {
                        NSString *email = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(CFBridgingRetain(emailID), i);
                        [tempEmailArray addObject:email];
                    }
                    
                    if (!firstName)
                    {
                        firstName = @"";
                    }
                    if (!lastName)
                    {
                        lastName = @"";
                    }
                    
                    
                    // user Image
                    NSData  *imgData = (__bridge_transfer NSData *) ABPersonCopyImageDataWithFormat(person, kABPersonImageFormatThumbnail);
                    UIImage *personImage;
                    
                    if (imgData.length>0)
                    {
                        personImage = [UIImage imageWithData:imgData];
                        imgData = nil;
                    }
                    else
                    {
                        personImage = [UIImage imageNamed:@"Default-480h.png"];
                    }
                    
                    
                    NSMutableString *asciiCharacters = [NSMutableString string];
                    for (NSInteger i = 32; i < 127; i++)
                    {
                        [asciiCharacters appendFormat:@"%c", (int)i];
                    }
                    NSCharacterSet *nonAsciiCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:asciiCharacters] invertedSet];
                    firstName = [[firstName componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                    lastName = [[lastName componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                    firstName = [NSString stringWithFormat:@"%@ %@",firstName,lastName];
                    
                    
                    for (CFIndex i = 0; i < ABMultiValueGetCount(phoneNumbers); i++)
                    {
                        
                        NSString *firstName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
                        NSString *lastName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
                        
                        if (!firstName)
                        {
                            firstName = @"";
                        }
                        if (!lastName)
                        {
                            lastName = @"";
                        }
                        
                        // FETCH PHONE NUMBER
                        
                        
                        NSString *phoneNumber1 = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(phoneNumbers, i);
                        if ([phoneNumber1 isEqualToString:@""])
                        {
                            phoneNumber1 = @"";
                        }
                        
                        addressBookNum = [addressBookNum stringByAppendingFormat: @":%@",phoneNumber1];
                        
                        while (([phoneNumber1 rangeOfString:@"("].location != NSNotFound) || ([phoneNumber1 rangeOfString:@")"].location != NSNotFound)   || ([phoneNumber1 rangeOfString:@" "].location != NSNotFound) || ([phoneNumber1 rangeOfString:@"-"].location != NSNotFound)   || ([phoneNumber1 rangeOfString:@","].location != NSNotFound)  || ([phoneNumber1 rangeOfString:@"*"].location != NSNotFound)  || ([phoneNumber1 rangeOfString:@"#"].location != NSNotFound)  || ([phoneNumber1 rangeOfString:@"."].location != NSNotFound)       )
                        {
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"(" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@")" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@" " withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"-" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"," withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"*" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"#" withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingOccurrencesOfString:@"." withString:@""];
                            phoneNumber1 = [phoneNumber1 stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                        }
                        
                        NSMutableString *asciiCharacters = [NSMutableString string];
                        for (NSInteger i = 32; i < 127; i++)
                        {
                            [asciiCharacters appendFormat:@"%c", (int)i];
                        }
                        
                        NSCharacterSet *nonAsciiCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:asciiCharacters] invertedSet];
                        phoneNumber1 = [[phoneNumber1 componentsSeparatedByCharactersInSet:nonAsciiCharacterSet] componentsJoinedByString:@""];
                        firstName = [NSString stringWithFormat:@"%@ %@",firstName,lastName];
                        
                        ankitStrring = nil;
                        ankitStrring = phoneNumber1;
                        
                        phoneNumber1 = [[phoneNumber1 componentsSeparatedByCharactersInSet: [[NSCharacterSet decimalDigitCharacterSet] invertedSet]] componentsJoinedByString:@""];
                        
                        if ([ankitStrring hasPrefix:@"+"])
                        {
                            phoneNumber1 =  [@"+" stringByAppendingString:phoneNumber1];
                        }
                        
                        [temp addObject:phoneNumber1];
                    }
                    
                    
                    NSDictionary *myDictionary = [[NSDictionary alloc]initWithObjectsAndKeys:
                                                  temp,@"number",
                                                  firstName,@"name",
                                                  tempEmailArray,@"email",
                                                  personImage,@"userImage",
                                                  nil];
                    
                    
                    [myTestingArray addObject:myDictionary];
                    
                }
            }
        }
        
        
        returnArray = [myTestingArray mutableCopy];
        
        
        
        NSMutableArray *contactBookPhoneNames = [[NSMutableArray alloc]init];
        NSMutableArray *contactBookPhoneNumbers = [[NSMutableArray alloc]init];
        NSMutableArray *contactBookEmailIds = [[NSMutableArray alloc]init];
        
        
        for (int count=0; count<returnArray.count; count++)
        {
            NSString *name = [[returnArray objectAtIndex:count]valueForKey:@"name"];
            [contactBookPhoneNames addObject:name];
            
            NSArray *number = [[returnArray objectAtIndex:count]valueForKey:@"number"];
            NSString *numberString = [number componentsJoinedByString:@"~"];
            [contactBookPhoneNumbers addObject:numberString];
            
            NSArray *emailID = [[returnArray objectAtIndex:count]valueForKey:@"email"];
            NSString *emailIDString = [emailID componentsJoinedByString:@"~"];
            [contactBookEmailIds addObject:emailIDString];
        }
        
        NSString *convertedNameString = [contactBookPhoneNames componentsJoinedByString:@"$#@$#"];
        NSString *convertedNumberString = [contactBookPhoneNumbers componentsJoinedByString:@","];
        NSString *convertedEmailIdString = [contactBookEmailIds componentsJoinedByString:@"$#@$#"];
        
        
        NSMutableDictionary *returnDictionary = [[NSMutableDictionary alloc]init];
        [returnDictionary setObject:convertedNameString forKey:@"name"];
        [returnDictionary setObject:convertedNumberString forKey:@"number"];
        [returnDictionary setObject:convertedEmailIdString forKey:@"email"];
        
        return returnDictionary;
    }
    @catch (NSException *exception)
    {
        NSLog(@"Exception is %@",exception.description);
    }
}



#pragma mark
#pragma mark Internet Unavailable
+(void)func_Alert_InternetUnavailable
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Internet Unavailable" message:@"Please check your Internet Connection." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

#pragma mark
#pragma mark Check Password Strength
+ (int)validateString:(NSString *)string withPattern:(NSString *)pattern caseSensitive:(BOOL)caseSensitive
{
    NSError *error = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:((caseSensitive) ? 0 : NSRegularExpressionCaseInsensitive) error:&error];
    
    NSAssert(regex, @"Unable to create regular expression");
    
    NSRange textRange = NSMakeRange(0, string.length);
    NSRange matchRange = [regex rangeOfFirstMatchInString:string options:NSMatchingReportProgress range:textRange];
    
    BOOL didValidate = 0;
    
    // Did we find a matching range
    if (matchRange.location != NSNotFound)
        didValidate = 1;
    
    return didValidate;
}


+(NSInteger)checkPasswordStrength:(NSString *)password
{
    NSInteger len = password.length;
    //will contains password strength
    int strength = 0;
    
    if (len <= 5) {
        strength++;
    } else if (len <= 7) {
        strength += 2;
    } else{
        strength += 3;
    }
    
    strength += [self validateString:password withPattern:REGEX_PASSWORD_ONE_UPPERCASE caseSensitive:YES];
    strength += [self validateString:password withPattern:REGEX_PASSWORD_ONE_LOWERCASE caseSensitive:YES];
    strength += [self validateString:password withPattern:REGEX_PASSWORD_ONE_NUMBER caseSensitive:YES];
    strength += [self validateString:password withPattern:REGEX_PASSWORD_ONE_SYMBOL caseSensitive:YES];
    
    if(strength <= 3)
    {
        return 0; //Password Strength Type Weak
    }
    else if(3 < strength && strength < 7)
    {
        return 1; //Password Strength Type Moderate
    }
    else
    {
        return 2; //Password Strength Type Strong
    }
}


#pragma mark
#pragma mark Alert 
+(void)func_AlertWithTitle:(NSString*)title andMessage: (NSString*)message
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:title message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}


#pragma mark
#pragma mark Delete All Temperoray Images From Document Directory
+(void)func_DeleteAllTemperaoryImagesFromDocumentDirectory
{
    NSString *extension = @"png";
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,     NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSArray *contents = [fileManager contentsOfDirectoryAtPath:documentsDirectory error:NULL];
    NSEnumerator *e = [contents objectEnumerator];
    NSString *filename;
    while ((filename = [e nextObject])) {
        
        if ([[filename pathExtension] isEqualToString:extension]) {
            
            [fileManager removeItemAtPath:[documentsDirectory     stringByAppendingPathComponent:filename] error:NULL];
        }
    }
}


#pragma mark
#pragma mark Delete All Temperoray Videos From Document Directory
+(void)func_DeleteAllTemperaoryVideosFromDocumentDirectory
{
    NSString *extension = @"mp4";
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,     NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSArray *contents = [fileManager contentsOfDirectoryAtPath:documentsDirectory error:NULL];
    NSEnumerator *e = [contents objectEnumerator];
    NSString *filename;
    while ((filename = [e nextObject])) {
        
        if ([[filename pathExtension] isEqualToString:extension]) {
            
            [fileManager removeItemAtPath:[documentsDirectory     stringByAppendingPathComponent:filename] error:NULL];
        }
    }
}


#pragma mark
#pragma mark Sort Data by Name
+(NSString*)sortNameWiseData : (NSString*)name
{
    NSString *_strHeader;
    
    NSString *firstLetter = [name substringToIndex: 1 ];
    
    if([firstLetter isEqualToString:@"A"] || [firstLetter isEqualToString:@"a"])
    {
        _strHeader = @"A";
    }
    else if([firstLetter isEqualToString:@"B"] || [firstLetter isEqualToString:@"b"])
    {
        _strHeader = @"B";
    }
    else if([firstLetter isEqualToString:@"C"] || [firstLetter isEqualToString:@"c"])
    {
        _strHeader = @"C";
    }
    else if([firstLetter isEqualToString:@"D"] || [firstLetter isEqualToString:@"d"])
    {
        _strHeader = @"D";
    }
    else if([firstLetter isEqualToString:@"E"] || [firstLetter isEqualToString:@"e"])
    {
        _strHeader = @"E";
    }
    else if([firstLetter isEqualToString:@"F"] || [firstLetter isEqualToString:@"f"])
    {
        _strHeader = @"F";
    }
    else if([firstLetter isEqualToString:@"G"] || [firstLetter isEqualToString:@"g"])
    {
        _strHeader = @"G";
    }
    else if([firstLetter isEqualToString:@"H"] || [firstLetter isEqualToString:@"h"])
    {
        _strHeader = @"H";
    }
    else if([firstLetter isEqualToString:@"I"] || [firstLetter isEqualToString:@"i"])
    {
        _strHeader = @"I";
    }
    else if([firstLetter isEqualToString:@"J"] || [firstLetter isEqualToString:@"j"])
    {
        _strHeader = @"J";
    }
    else if([firstLetter isEqualToString:@"K"] || [firstLetter isEqualToString:@"k"])
    {
        _strHeader = @"K";
    }
    else if([firstLetter isEqualToString:@"L"] || [firstLetter isEqualToString:@"l"])
    {
        _strHeader = @"L";
    }
    else if([firstLetter isEqualToString:@"M"] || [firstLetter isEqualToString:@"m"])
    {
        _strHeader = @"M";
    }
    else if([firstLetter isEqualToString:@"N"] || [firstLetter isEqualToString:@"n"])
    {
        _strHeader = @"N";
    }
    else if([firstLetter isEqualToString:@"O"] || [firstLetter isEqualToString:@"o"])
    {
        _strHeader = @"O";
    }
    else if([firstLetter isEqualToString:@"P"] || [firstLetter isEqualToString:@"p"])
    {
        _strHeader = @"P";
    }
    else if([firstLetter isEqualToString:@"Q"] || [firstLetter isEqualToString:@"q"])
    {
        _strHeader = @"Q";
    }
    else if([firstLetter isEqualToString:@"R"] || [firstLetter isEqualToString:@"r"])
    {
        _strHeader = @"R";
    }
    else if([firstLetter isEqualToString:@"S"] || [firstLetter isEqualToString:@"s"])
    {
        _strHeader = @"S";
    }
    else if([firstLetter isEqualToString:@"T"] || [firstLetter isEqualToString:@"t"])
    {
        _strHeader = @"T";
    }
    else if([firstLetter isEqualToString:@"U"] || [firstLetter isEqualToString:@"u"])
    {
        _strHeader = @"U";
    }
    else if([firstLetter isEqualToString:@"V"] || [firstLetter isEqualToString:@"v"])
    {
        _strHeader = @"V";
    }
    else if([firstLetter isEqualToString:@"W"] || [firstLetter isEqualToString:@"w"])
    {
        _strHeader = @"W";
    }
    else if([firstLetter isEqualToString:@"X"] || [firstLetter isEqualToString:@"x"])
    {
        _strHeader = @"X";
    }
    else if([firstLetter isEqualToString:@"Y"] || [firstLetter isEqualToString:@"y"])
    {
        _strHeader = @"Y";
    }
    else if([firstLetter isEqualToString:@"Z"] || [firstLetter isEqualToString:@"z"])
    {
        _strHeader = @"Z";
    }
    else
    {
        _strHeader = @"#";
    }
    return _strHeader;
}







@end
