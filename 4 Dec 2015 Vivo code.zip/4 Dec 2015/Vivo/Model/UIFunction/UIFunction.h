//
//  UiFunction.h
//  FakhrooUpdationApp
//
//  Created by Sukhreet on 3/5/15.
//  Copyright (c) 2015 Apto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>



@interface UIFunction : NSObject



+(UIButton*)createButton:(CGRect)frame bckgroundColor:(UIColor*)backgroundColor image:(UIImage*)image title:(NSString*)title font:(UIFont*)font titleColor:(UIColor*)titleColor;



+(UILabel*)createLable:(CGRect)frame bckgroundColor:(UIColor*)backgroundColor title:(NSString*)title font:(UIFont*)font titleColor:(UIColor*)titleColor;



+(UIImageView*)createUIImageView:(CGRect)frame backgroundColor:(UIColor*)backgroundColor image:(UIImage*)image isLogo:(BOOL)isLogo;



+(BOOL) validateEmail:(NSString *)checkString;



+(UIView*)createHeader:(CGRect)frame bckgroundColor:(UIColor*)backgroundColor;

+(UIView*)createUIViews : (CGRect)frame bckgroundColor:(UIColor*)backgroundColor;

+(UITextField*)createTextField : (CGRect)frame font:(UIFont*)font placeholder:(NSString*)placeholder;

+(UIActivityIndicatorView*)createActivityIndicatorView :(CGRect)frame;

+ (NSString *)deviceUUID;

+(UIImage*)imageWithImage: (UIImage*) sourceImage scaledToWidth: (float) i_width scaledToHeight: (float) i_height;


+(NSString*) autoDetectCountryCode;

+(NSString*) func_GetCountryNameFromCountryCode : (NSString*)countryCode;


+(NSMutableDictionary*) FetchAllContactsFromUserPhoneBook;

+(NSMutableArray*)func_GetAllCountries_Name;

+(NSMutableArray*)func_GetAllCountries_Code;

+(void)func_Alert_InternetUnavailable;

+(NSInteger)checkPasswordStrength:(NSString *)password;

+(void)func_AlertWithTitle:(NSString*)title andMessage: (NSString*)message;

+(void)func_DeleteAllTemperaoryImagesFromDocumentDirectory;

+(void)func_DeleteAllTemperaoryVideosFromDocumentDirectory;

+(NSString*)sortNameWiseData : (NSString*)name;



@end
