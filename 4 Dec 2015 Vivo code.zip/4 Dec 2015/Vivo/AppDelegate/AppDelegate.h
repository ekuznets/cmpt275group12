//
//  AppDelegate.h
//  Vivo
//
//  Created by Sukhreeton 30/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HTKnockDetector.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navController;
@property (nonatomic, strong) HTKnockDetector * knockDetector;


-(void)functionToHandleInvalidAccessToken;
-(void)showIndicator;
-(void)hideIndicator;


@end

AppDelegate *appDelegate(void);
