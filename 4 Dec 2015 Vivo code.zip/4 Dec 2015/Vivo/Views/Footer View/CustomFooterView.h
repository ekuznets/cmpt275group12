//
//  CustomFooterView.h
//  Yada
//
//  Created by Sukhreet on 19/12/14.
//  Copyright (c) 2014 Sukhreet. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol customFooterMethod;
@interface CustomFooterView : UIView
{
    id <customFooterMethod> footerDelegate;
}

- (void)changeImage : (NSString*)selectedButton;

@property (retain) id<customFooterMethod> footerDelegate;
@end


@protocol customFooterMethod <NSObject>
- (void)myPillButtonFunction;
- (void)healthCanadaAlertsButtonFunction;
-(void) sickPlottersButtonFunction;

@end

