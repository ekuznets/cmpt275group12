


#define miscoBold @"Helvetica-Bold"
#define miscoLight @"Helvetica-Light"
#define miscoRegular @"Helvetica"

#define kHealthAlertsStatus @"health canada alerts status"
#define kFallDetection @"fall detection"
#define kLoginData @"Login Data"
#define kSearchDomainForMyPill @"Search Domain for My Pill"
#define kMyOwnPillList @"my own pill list"
