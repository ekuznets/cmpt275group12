//
//  LogInVC.h
//  Vivo
//
//  Created by Sukhreet on 30/10/15.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogInVC : UIViewController

@end
