//
//  ViewController.m
//  Vivo
//
//  Created by Sukhreet on 30/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "ViewController.h"
#import "LogInVC.h"
#import "MyPillVC.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate>

@end

@implementation ViewController
{
    NSMutableDictionary *_dictinarySignUp;
    NSMutableArray *_arrayOfKeys;
    UITableView *_tableViewSignUp;
    NSString *_strEmailToServer;
    NSString *_strPasswordoServer;
    NSArray *_arrayLocations;
    NSArray *_arrayLocations_Short;
    UIView *_viewLocationPicker;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"Jai Shri Ram");
    

    _arrayLocations = [NSArray arrayWithObjects:@"Albera",@"British Columbia",@"Manitoba",@"New Brunswick",@"Newfoundland & Labrador",@"Nova Scotia",@"Northwest Territories",@"Nunavut",@"Ontario",@"Prince Edward Island",@"Quebec",@"Saskatchewan",@"Yukon", nil];
    
    _arrayLocations_Short = [NSArray arrayWithObjects:@"AB",@"BC",@"MB",@"NB",@"NL",@"NS",@"NT",@"NU",@"ONT",@"PE",@"QC",@"SK",@"YT", nil];

    NSLog(@"________ %@",[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]);
    if ([[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"password"]length]>0)
    {
        MyPillVC *myPill = [[MyPillVC alloc]init];
        [self.navigationController pushViewController:myPill animated:YES];
    }
    else
    {
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_img.jpg"]];
        _dictinarySignUp = [[NSMutableDictionary alloc]initWithObjectsAndKeys:
                            @"",@"Email",
                            @"",@"Password",
                            @"",@"location",
                            @"",@"emergency_contact",

                            nil];
        _arrayOfKeys = [[NSMutableArray alloc]initWithObjects:@"Email",@"Password",@"Location",@"Emergency Email (Optional)", nil];
        
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:kFallDetection];
        [[NSUserDefaults standardUserDefaults]synchronize];

        
        UIImageView *_imgViewLogo = [UIFunction createUIImageView:CGRectMake(self.view.frame.size.width/2.0-[UIImage imageNamed:@"logo.png"].size.width/2.0, 50, [UIImage imageNamed:@"logo.png"].size.width, [UIImage imageNamed:@"logo.png"].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo.png"] isLogo:NO];
        [self.view addSubview:_imgViewLogo];
        
        // UITable View which contains all Field
        _tableViewSignUp = [self createTableView:CGRectMake(20,_imgViewLogo.frame.size.height+_imgViewLogo.frame.origin.y+70, self.view.frame.size.width-40, 200) backgroundColor:[UIColor whiteColor]];
        _tableViewSignUp.showsVerticalScrollIndicator = YES;
        _tableViewSignUp.layer.cornerRadius = 5.0;
        [self.view addSubview:_tableViewSignUp];
        
        
        UIButton *_btnSignUp = [UIFunction createButton:CGRectMake(_tableViewSignUp.frame.origin.x, _tableViewSignUp.frame.size.height+_tableViewSignUp.frame.origin.y+10, _tableViewSignUp.frame.size.width, 50) bckgroundColor:[UIColor whiteColor] image:nil title:@"Sign Up" font:[UIFont fontWithName:miscoRegular size:18.0] titleColor:[UIColor colorWithRed:15.0/255 green:73.0/255 blue:136.0/255 alpha:1.0]];
        _btnSignUp.layer.cornerRadius = 5.0;
        [_btnSignUp addTarget:self action:@selector(func_SignUp) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_btnSignUp];
        
        UILabel *_lblAlreadyAccount = [UIFunction createLable:CGRectMake(_tableViewSignUp.frame.origin.x, self.view.frame.size.height-55, 220, 50) bckgroundColor:[UIColor clearColor] title:@"Already have an account ?" font:[UIFont fontWithName:miscoRegular size:18.0] titleColor:[UIColor whiteColor]];
        _lblAlreadyAccount.textAlignment = NSTextAlignmentLeft;
        [self.view addSubview:_lblAlreadyAccount];
        
        
        UIButton *_btnLogIn = [UIFunction createButton:CGRectMake(_lblAlreadyAccount.frame.origin.x+_lblAlreadyAccount.frame.size.width, _lblAlreadyAccount.frame.origin.y+10, 70, 30) bckgroundColor:[UIColor clearColor] image:nil title:@"LogIn" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
        _btnLogIn.layer.cornerRadius = 5.0;
        [_btnLogIn addTarget:self action:@selector(func_LogIn) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_btnLogIn];
        
        UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(_btnLogIn.frame.origin.x+5, _btnLogIn.frame.size.height+_btnLogIn.frame.origin.y, _btnLogIn.frame.size.width-10, 1) bckgroundColor:[UIColor whiteColor]];
        [self.view addSubview:_viewDivider];
    }
}

#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}

#pragma mark
#pragma mark Table View Data Source and Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[_dictinarySignUp allKeys] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];
    
    NSString *_strKey = [NSString stringWithFormat:@"%@",[_arrayOfKeys objectAtIndex:indexPath.row]];
    
    
    if (indexPath.row == 2) // location
    {
        NSString *_strLocation = [_dictinarySignUp valueForKey:@"location"];
        
        UILabel *_lblLocation = [UIFunction createLable:CGRectMake(25, 0, tableView.frame.size.width-50, 50) bckgroundColor:[UIColor clearColor] title:_strLocation font:[UIFont fontWithName:miscoRegular size:16] titleColor:[UIColor blackColor]];
        _lblLocation.userInteractionEnabled = true;
        _lblLocation.tag = 98980;
        
        UITapGestureRecognizer *tapToSelectLocation = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(func_SelectLocation)];
        [_lblLocation addGestureRecognizer:tapToSelectLocation];
        [cell.contentView addSubview:_lblLocation];
        
        if (_strLocation.length == 0)
        {
            _lblLocation.text = @"Location";
            _lblLocation.textColor = [UIColor lightGrayColor];
        }
    }
    else
    {
        UITextField *_textField = [[UITextField alloc]init];
        _textField.frame = CGRectMake(25, 0, tableView.frame.size.width-50, 50);
        _textField.borderStyle = UITextBorderStyleNone;
        _textField.font = [UIFont fontWithName:miscoRegular size:16];
        _textField.keyboardType = UIKeyboardTypeDefault;
        _textField.returnKeyType = UIReturnKeyDone;
        _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        _textField.tag = indexPath.row+100;
        _textField.text = [_dictinarySignUp valueForKey:_strKey];
        _textField.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        _textField.delegate = self;
        _textField.secureTextEntry = NO;
        _textField.placeholder = _strKey;
        _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _textField.textColor = [UIColor blackColor];
        _textField.leftViewMode=UITextFieldViewModeAlways;
        _textField.autocapitalizationType= UITextAutocapitalizationTypeNone;
        _textField.autocorrectionType = UITextAutocorrectionTypeNo;
        _textField.backgroundColor = [UIColor clearColor];
        [self.view endEditing:YES];
        [cell.contentView addSubview:_textField];
        
        if (_textField.tag == 101)
        {
            _textField.secureTextEntry = YES;
        }
    }
    
 
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(25, frame.size.height-1, tableView.frame.size.width-50, 1) bckgroundColor:[UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]];
    [cell.contentView addSubview:_viewDivider];
    
    
 
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.userInteractionEnabled = true;
    return cell;

}


#pragma mark
#pragma mark TextField Delegate
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self dismissInputControls];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 100) //email
    {
        NSString *_strEmail = [[textField.text stringByReplacingCharactersInRange:range withString:string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [_dictinarySignUp setValue:_strEmail forKey:@"Email"];
    }
    else if (textField.tag == 101) // password
    {
        NSString *_strPassword = [[textField.text stringByReplacingCharactersInRange:range withString:string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [_dictinarySignUp setValue:_strPassword forKey:@"Password"];
    }
    else if (textField.tag == 103) // emergency email
    {
        NSString *_strEmail = [[textField.text stringByReplacingCharactersInRange:range withString:string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [_dictinarySignUp setValue:_strEmail forKey:@"emergency_contact"];

    }
    
    return YES;
}


- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    if (textField.tag == 100) //email
    {
        [_dictinarySignUp setValue:@"" forKey:@"Email"];
    }
    else if (textField.tag == 101) // password
    {
        [_dictinarySignUp setValue:@"" forKey:@"Password"];
    }
    else if (textField.tag == 103) // emergency email
    {
        [_dictinarySignUp setValue:@"" forKey:@"emergency_contact"];
    }

    return YES;
}

#pragma mark
#pragma mark func_SignUp
-(void)func_SignUp
{
    NSLog(@"func_SignUp is %@",_dictinarySignUp);
    
    _strEmailToServer = [[_dictinarySignUp valueForKey:@"Email"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _strPasswordoServer = [[_dictinarySignUp valueForKey:@"Password"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *_strLocation = [_dictinarySignUp valueForKey:@"location"];
    NSString *_strEmergencyEmail = [[_dictinarySignUp valueForKey:@"emergency_contact"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSInteger index = [_arrayLocations indexOfObject:_strLocation];
    _strLocation = [_arrayLocations_Short objectAtIndex:index];

    NSString *deviceID = [[NSUserDefaults standardUserDefaults] valueForKey:@"device_token"];
    if (deviceID.length == 0)
    {
        deviceID = @"";
    }
    

    
    if (_strEmailToServer.length == 0)
    {
        [UIFunction func_AlertWithTitle:@"Required" andMessage:@"Please enter your e-mail address."];
    }
    else if ([UIFunction validateEmail:_strEmailToServer] == 0)
    {
        [UIFunction func_AlertWithTitle:@"Error" andMessage:@"Please enter a valid e-mail address."];
    }
    else if (_strPasswordoServer.length == 0)
    {
        [UIFunction func_AlertWithTitle:@"Required" andMessage:@"Please enter Password."];
    }
    else if (_strLocation.length == 0)
    {
        [UIFunction func_AlertWithTitle:@"Required" andMessage:@"Please select your location."];
    }
    else if (_strEmergencyEmail.length > 0 && [UIFunction validateEmail:_strEmergencyEmail] == 0)
    {
        [UIFunction func_AlertWithTitle:@"Error" andMessage:@"Please enter a valid e-mail address."];
    }

    else
    {
        [self.view endEditing:YES];
        
        Reachability *reach = [Reachability reachabilityForInternetConnection];
        NetworkStatus netStatus = [reach currentReachabilityStatus];
        
        if (netStatus == NotReachable)
        {
            [UIFunction func_Alert_InternetUnavailable];
        }
        else
        {
            NSLog(@"Call API For Sign Up");
            [self.view endEditing:YES];

            [appDelegate() showIndicator];
            ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/signupV2.php"]]];
            [Request setTimeOutSeconds:300];
            Request.shouldAttemptPersistentConnection   = NO;
            Request.delegate=self;
            [Request setRequestMethod:@"POST"];
            [Request setPostValue:_strEmailToServer forKey:@"email"];
            [Request setPostValue:_strPasswordoServer forKey:@"password"];
            [Request setPostValue:_strLocation forKey:@"location"];
            [Request setPostValue:_strEmergencyEmail forKey:@"contact"];
            [Request setPostValue:deviceID forKey:@"device_token"];
            Request.tag = 45454645;
            [Request startAsynchronous];
        }
    }
}

#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 45454645) // register new user
    {
        @try
        {
            [appDelegate() hideIndicator];

            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[request responseData] options:kNilOptions error:nil];
            NSLog(@"json to get register user %@",[json objectForKey:@"response"]);

            if ([json objectForKey:@"response"])
            {
                [[NSUserDefaults standardUserDefaults]setObject:[json objectForKey:@"response"] forKey:kLoginData];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                MyPillVC *myPill = [[MyPillVC alloc]init];
                [self.navigationController pushViewController:myPill animated:YES];
            }
            else if ([json objectForKey:@"error"])
            {
                [UIFunction func_AlertWithTitle:@"Error" andMessage:[json objectForKey:@"error"]];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
}


#pragma mark
#pragma mark func_LogIn
-(void)func_LogIn
{
    NSLog(@"func_LogIn");
    
    LogInVC *_logIn = [[LogInVC alloc]init];
    [self.navigationController pushViewController:_logIn animated:YES];
}

#pragma mark
#pragma mark Picker View Data Source and Delegates
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag == 1210)
    {
        return _arrayLocations.count;
    }
    return 0;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if(pickerView.tag==1210)
    {
        return 1;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView.tag == 1210)
    {
        return [_arrayLocations objectAtIndex:row];
    }
    return 0;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView.tag == 1210)
    {
        [_dictinarySignUp setObject:[_arrayLocations objectAtIndex:row] forKey:@"location"];
        [_tableViewSignUp reloadData];
    }
}



#pragma mark
#pragma mark func_SelectLocation
-(void)func_SelectLocation
{
    NSLog(@"func_SelectLocation");
    
    [self.view endEditing:YES];
    
    [_viewLocationPicker removeFromSuperview];
    _viewLocationPicker = nil;
    _viewLocationPicker = [UIFunction createUIViews:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 246) bckgroundColor:[UIColor colorWithRed:218.0/255 green:222.0/255 blue:230.0/255 alpha:1.0]];
    [self.view addSubview:_viewLocationPicker];
    
    
    UIButton *_btnDone = [UIFunction createButton:CGRectMake(_viewLocationPicker.frame.size.width-70, 0, 70, 50) bckgroundColor:[UIColor clearColor] image:nil title:@"Done" font:[UIFont fontWithName:miscoBold size:16.0] titleColor:[UIColor colorWithRed:67.0/255 green:133.0/255 blue:245.0/255 alpha:1.0]];
    [_btnDone addTarget:self action:@selector(dismissInputControls) forControlEvents:UIControlEventTouchUpInside];
    [_viewLocationPicker addSubview:_btnDone];
    
    
    UIPickerView *_locationPickerView =  [[UIPickerView alloc]init];
    _locationPickerView.frame = CGRectMake(0, _viewLocationPicker.frame.size.height-216.0, self.view.frame.size.width, 216.0);
    _locationPickerView.delegate=self;
    _locationPickerView.dataSource=self;
    _locationPickerView.showsSelectionIndicator=YES;
    _locationPickerView.backgroundColor = [UIColor clearColor];
    _locationPickerView.tag = 1210;
    [_viewLocationPicker addSubview:_locationPickerView];
    
    
    [UIView animateWithDuration:0.3 animations:^{
        
        _viewLocationPicker.frame = CGRectMake(0, self.view.frame.size.height-246, self.view.frame.size.width, 246);
        
    } completion:^(BOOL finished) {
        
        [_dictinarySignUp setObject:[_arrayLocations objectAtIndex:0] forKey:@"location"];
        [_tableViewSignUp reloadData];
    }];

    
   

}

-(void)dismissInputControls
{
    [UIView animateWithDuration:0.3 animations:^{
       
        _viewLocationPicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 246);
    
    } completion:^(BOOL finished) {
        
        [_viewLocationPicker removeFromSuperview];
        _viewLocationPicker = nil;
    }];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
