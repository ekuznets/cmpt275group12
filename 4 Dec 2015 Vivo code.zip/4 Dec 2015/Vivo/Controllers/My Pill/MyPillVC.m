//
//  MyPillVC.m
//  Vivo
//
//  Created by Sukhreet on 30/10/15.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "MyPillVC.h"
#import "SideMenu.h"
#import "CustomFooterView.h"
#import "HealthAlertsVC.h"
#import "SicknessPlotterVC.h"
#import "SettingsVC.h"
#import "FallDetectionVC.h"



@interface MyPillVC () <sideMenuProtocol, UIScrollViewDelegate, customFooterMethod, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource>

@end

@implementation MyPillVC
{
    SideMenu *_viewSideMenu;
    CustomFooterView *footerView;
    
    UIView *_backgroundViewForMyPillsAndSearch;
    UIButton *_btnSchedule;
    UIButton *_btnSearch;
    UIView *_whiteLineView;
    UIScrollView *landingPageScroll;
    BOOL isScheduleVisible;
    UITableView *_tableSeach;
    NSMutableArray *_arrayResult;
    NSMutableArray *_arrayToDisplayMyPills;
    UITableView *_tableMyOwnPills;

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [footerView changeImage:@"1"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    isScheduleVisible = YES;
    _arrayResult = [[NSMutableArray alloc]init];
    _arrayToDisplayMyPills = [[[NSUserDefaults standardUserDefaults]valueForKey:kMyOwnPillList]mutableCopy];
    if (_arrayToDisplayMyPills.count==0)
    {
        _arrayToDisplayMyPills = [[NSMutableArray alloc]init];
    }

    
    
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnSideMenu = [UIFunction createButton:CGRectMake(10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] title:nil font:nil titleColor:nil];
    [_btnSideMenu addTarget:self action:@selector(func_SideMenuButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnSideMenu];
    
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"My Pill" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];
    
    
    UIButton *_btn_FallDetection = [UIFunction createButton:CGRectMake(self.view.frame.size.width-[UIImage imageNamed:@"fall_detection.png"].size.width, 20, [UIImage imageNamed:@"fall_detection.png"].size.width, [UIImage imageNamed:@"fall_detection.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"fall_detection.png"] title:nil font:nil titleColor:nil];
    [_btn_FallDetection addTarget:self action:@selector(func_FallDetection) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btn_FallDetection];
    
    
    [footerView removeFromSuperview];
    footerView = nil;
    footerView = [[CustomFooterView alloc]init];
    footerView.frame = CGRectMake(0, self.view.frame.size.height-49, self.view.frame.size.width, 49);
    [footerView setBackgroundColor:[UIColor colorWithRed:247.0/255 green:247.0/255 blue:247.0/255 alpha:1.0]];
    footerView.footerDelegate=self;
    [self.view addSubview:footerView];
    [footerView changeImage:@"1"];
    
    
    // Scrollable View
    
    [_backgroundViewForMyPillsAndSearch removeFromSuperview];
    _backgroundViewForMyPillsAndSearch = nil;
    _backgroundViewForMyPillsAndSearch = [UIFunction createUIViews:CGRectMake(0, _viewHeader.frame.size.height+_viewHeader.frame.origin.y, self.view.frame.size.width, 50) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    _backgroundViewForMyPillsAndSearch.layer.shadowColor = [UIColor grayColor].CGColor;
    _backgroundViewForMyPillsAndSearch.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    _backgroundViewForMyPillsAndSearch.layer.shadowOpacity = 1.0;
    _backgroundViewForMyPillsAndSearch.layer.shadowRadius = 2.0;
    [self.view addSubview:_backgroundViewForMyPillsAndSearch];
    
    
    [_btnSchedule removeFromSuperview];
    _btnSchedule = nil;
    _btnSchedule = [UIFunction createButton:CGRectMake(0, 0, _backgroundViewForMyPillsAndSearch.frame.size.width/2.0, 48) bckgroundColor:[UIColor clearColor] image:nil title:@"Schedule" font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor whiteColor]];
    [_btnSchedule addTarget:self action:@selector(func_ScheduleButtonFunction) forControlEvents:UIControlEventTouchUpInside];
    [_backgroundViewForMyPillsAndSearch addSubview:_btnSchedule];
    
    
    [_btnSearch removeFromSuperview];
    _btnSearch = nil;
    _btnSearch = [UIFunction createButton:CGRectMake(_btnSchedule.frame.size.width+_btnSchedule.frame.origin.x, 0, _backgroundViewForMyPillsAndSearch.frame.size.width/2.0, 49) bckgroundColor:[UIColor clearColor] image:nil title:@"Search" font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor whiteColor]];
    [_btnSearch addTarget:self action:@selector(func_SearchButtonFunction) forControlEvents:UIControlEventTouchUpInside];
    [_backgroundViewForMyPillsAndSearch addSubview:_btnSearch];
    
    
    _whiteLineView = [[UIView alloc]init];
    _whiteLineView.frame = CGRectMake(0, 48, _backgroundViewForMyPillsAndSearch.frame.size.width/2.0, 2);
    _whiteLineView.backgroundColor = [UIColor whiteColor];
    [_backgroundViewForMyPillsAndSearch addSubview:_whiteLineView];

    
    landingPageScroll=[[UIScrollView alloc]initWithFrame:CGRectMake(0, _backgroundViewForMyPillsAndSearch.frame.size.height+_backgroundViewForMyPillsAndSearch.frame.origin.y+2, self.view.frame.size.width, footerView.frame.origin.y-_backgroundViewForMyPillsAndSearch.frame.size.height-_backgroundViewForMyPillsAndSearch.frame.origin.y-2)];
    landingPageScroll.backgroundColor=[UIColor clearColor];
    landingPageScroll.pagingEnabled=TRUE;
    landingPageScroll.delegate=self;
    landingPageScroll.tag=857412586;
    self.automaticallyAdjustsScrollViewInsets = NO;
    landingPageScroll.bounces = NO;
    landingPageScroll.showsHorizontalScrollIndicator=NO;
    landingPageScroll.showsVerticalScrollIndicator=NO;
    [landingPageScroll setContentOffset:CGPointMake(self.view.frame.size.width, 0) animated:NO];
    [landingPageScroll setContentSize:CGSizeMake(self.view.frame.size.width*2, landingPageScroll.frame.size.height)];
    [self.view addSubview:landingPageScroll];
    [landingPageScroll scrollRectToVisible:CGRectMake(0,0,self.view.frame.size.width,landingPageScroll.frame.size.height) animated:YES];
    
    
    [_tableMyOwnPills removeFromSuperview];
    _tableMyOwnPills = nil;
    _tableMyOwnPills = [self createTableView:CGRectMake(15, 0, self.view.frame.size.width-30, landingPageScroll.frame.size.height) backgroundColor:[UIColor clearColor]];
    _tableMyOwnPills.tag = 4949;
    [landingPageScroll addSubview:_tableMyOwnPills];

    
    
    UISearchBar *searchBar = [[UISearchBar alloc] init];
    searchBar.frame = CGRectMake(self.view.frame.size.width+15, 10, self.view.frame.size.width-30, 30);
    searchBar.delegate=self;
    searchBar.showsCancelButton = NO;
    searchBar.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    searchBar.tintColor = [UIColor lightGrayColor];
    searchBar.layer.cornerRadius = 5.0;
    searchBar.clipsToBounds = YES;
    searchBar.searchBarStyle = UISearchBarStyleMinimal;
    searchBar.userInteractionEnabled = YES;
    searchBar.placeholder = @"Search";
    [landingPageScroll addSubview:searchBar];
    
    
    
    [_tableSeach removeFromSuperview];
    _tableSeach = nil;
    _tableSeach = [self createTableView:CGRectMake(self.view.frame.size.width+15, searchBar.frame.size.height+searchBar.frame.origin.y, self.view.frame.size.width-30, landingPageScroll.frame.size.height-searchBar.frame.size.height-searchBar.frame.origin.y) backgroundColor:[UIColor clearColor]];
    _tableSeach.tag = 5050;
    [landingPageScroll addSubview:_tableSeach];
    
    
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:kSearchDomainForMyPill]count]==0)
    {
        [self func_FetchAllSearchDomainData];
    }
    
    
    NSLog(@"____ %@",_arrayResult);
    
    
}

#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}

#pragma mark
#pragma mark func_FallDetection
-(void)func_FallDetection
{
    NSLog(@"func_FallDetection");
    
    FallDetectionVC *_detection = [[FallDetectionVC alloc]init];
    [self.navigationController pushViewController:_detection animated:YES];
}

#pragma mark
#pragma mark Table View DataSource and Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 5050)
    {
        return 85;
    }
    else
    {
        return 110;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag == 5050)
    {
        return _arrayResult.count;
    }
    else
    {
        return _arrayToDisplayMyPills.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];

    if (tableView.tag == 5050)
    {
        NSString *_strDrugNumber = [NSString stringWithFormat:@"%@",[[_arrayResult objectAtIndex:indexPath.row] valueForKey:@"drug_number"]];
        
        NSString *_strDINNumber = [NSString stringWithFormat:@"%@",[[_arrayResult objectAtIndex:indexPath.row] valueForKey:@"din_number"]];
        
        NSString *_strPillName = [NSString stringWithFormat:@"%@",[[_arrayResult objectAtIndex:indexPath.row] valueForKey:@"pill_name"]];
        
        
        UILabel *_lblDrugNameStatic = [UIFunction createLable:CGRectMake(10, 5, 80, 20) bckgroundColor:[UIColor clearColor] title:@"Name :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugNameStatic];
        
        UILabel *_lblDrugName = [UIFunction createLable:CGRectMake(_lblDrugNameStatic.frame.size.width+_lblDrugNameStatic.frame.origin.x, 5, tableView.frame.size.width-_lblDrugNameStatic.frame.size.width-_lblDrugNameStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strPillName font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugName];
        
        
        UILabel *_lblDrugNumberStatic = [UIFunction createLable:CGRectMake(10, _lblDrugNameStatic.frame.size.height+_lblDrugNameStatic.frame.origin.y+5, _lblDrugNameStatic.frame.size.width, 20) bckgroundColor:[UIColor clearColor] title:@"Number :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugNumberStatic];
        
        
        UILabel *_lblDrugNumber = [UIFunction createLable:CGRectMake(_lblDrugNumberStatic.frame.size.width+_lblDrugNumberStatic.frame.origin.x, _lblDrugNumberStatic.frame.origin.y, tableView.frame.size.width-_lblDrugNumberStatic.frame.size.width-_lblDrugNumberStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strDrugNumber font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugNumber];
        
        
        UILabel *_lblDINStatic = [UIFunction createLable:CGRectMake(10, _lblDrugNumberStatic.frame.size.height+_lblDrugNumberStatic.frame.origin.y+5, _lblDrugNameStatic.frame.size.width, 20) bckgroundColor:[UIColor clearColor] title:@"DIN :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDINStatic];
        
        
        UILabel *_lblDIN = [UIFunction createLable:CGRectMake(_lblDINStatic.frame.size.width+_lblDINStatic.frame.origin.x, _lblDINStatic.frame.origin.y, tableView.frame.size.width-_lblDINStatic.frame.size.width-_lblDINStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strDINNumber font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDIN];
    }
    
    else
    {
        NSString *_strDrugNumber = [NSString stringWithFormat:@"%@",[[_arrayToDisplayMyPills objectAtIndex:indexPath.row] valueForKey:@"drug_number"]];
        
        NSString *_strDINNumber = [NSString stringWithFormat:@"%@",[[_arrayToDisplayMyPills objectAtIndex:indexPath.row] valueForKey:@"din_number"]];
        
        NSString *_strPillName = [NSString stringWithFormat:@"%@",[[_arrayToDisplayMyPills objectAtIndex:indexPath.row] valueForKey:@"pill_name"]];
        
        NSString *_strPillTime = [NSString stringWithFormat:@"%@",[[_arrayToDisplayMyPills objectAtIndex:indexPath.row] valueForKey:@"time"]];

        

        UILabel *_lblDrugNameStatic = [UIFunction createLable:CGRectMake(10, 5, 80, 20) bckgroundColor:[UIColor clearColor] title:@"Name :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugNameStatic];
        
        UILabel *_lblDrugName = [UIFunction createLable:CGRectMake(_lblDrugNameStatic.frame.size.width+_lblDrugNameStatic.frame.origin.x, 5, tableView.frame.size.width-_lblDrugNameStatic.frame.size.width-_lblDrugNameStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strPillName font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugName];
        
        
        UILabel *_lblDrugNumberStatic = [UIFunction createLable:CGRectMake(10, _lblDrugNameStatic.frame.size.height+_lblDrugNameStatic.frame.origin.y+5, _lblDrugNameStatic.frame.size.width, 20) bckgroundColor:[UIColor clearColor] title:@"Number :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugNumberStatic];
        
        
        UILabel *_lblDrugNumber = [UIFunction createLable:CGRectMake(_lblDrugNumberStatic.frame.size.width+_lblDrugNumberStatic.frame.origin.x, _lblDrugNumberStatic.frame.origin.y, tableView.frame.size.width-_lblDrugNumberStatic.frame.size.width-_lblDrugNumberStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strDrugNumber font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDrugNumber];
        
        
        UILabel *_lblDINStatic = [UIFunction createLable:CGRectMake(10, _lblDrugNumberStatic.frame.size.height+_lblDrugNumberStatic.frame.origin.y+5, _lblDrugNameStatic.frame.size.width, 20) bckgroundColor:[UIColor clearColor] title:@"DIN :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDINStatic];
        
        
        UILabel *_lblDIN = [UIFunction createLable:CGRectMake(_lblDINStatic.frame.size.width+_lblDINStatic.frame.origin.x, _lblDINStatic.frame.origin.y, tableView.frame.size.width-_lblDINStatic.frame.size.width-_lblDINStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strDINNumber font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblDIN];

        
        UILabel *_lblTimeStatic = [UIFunction createLable:CGRectMake(10, _lblDINStatic.frame.size.height+_lblDINStatic.frame.origin.y+5, _lblDrugNameStatic.frame.size.width, 20) bckgroundColor:[UIColor clearColor] title:@"Time :" font:[UIFont fontWithName:miscoBold size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblTimeStatic];
        
        UILabel *_lblTime = [UIFunction createLable:CGRectMake(_lblTimeStatic.frame.size.width+_lblTimeStatic.frame.origin.x, _lblTimeStatic.frame.origin.y, tableView.frame.size.width-_lblTimeStatic.frame.size.width-_lblTimeStatic.frame.origin.x-5, 20) bckgroundColor:[UIColor clearColor] title:_strPillTime font:[UIFont fontWithName:miscoRegular size:14.0] titleColor:[UIColor blackColor]];
        [cell.contentView addSubview:_lblTime];

    }


    
    UIView *dividerView = [[UIView alloc]init];
    dividerView.frame = CGRectMake(0, frame.size.height-1, tableView.frame.size.width, 1);
    dividerView.backgroundColor = [UIColor colorWithRed:211.0/255 green:211.0/255 blue:211.0/255 alpha:1.0];
    [cell.contentView addSubview:dividerView];

    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 5050)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        UIDatePicker *picker = [[UIDatePicker alloc] init];
        [picker setDatePickerMode:UIDatePickerModeDateAndTime];
        [alertController.view addSubview:picker];
        
        [alertController addAction:({
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                NSLog(@"OK");
                NSLog(@"%@ and %@",picker.date,[_arrayResult objectAtIndex:indexPath.row]);
                
                [self func_SetLocalNotification : picker.date]; // set local notification
                
                // set data in my own pills table to display my own pill list.
                NSString *_strTime = [self func_ConvertDate:picker.date];
                NSMutableDictionary *_dictionaryToAddTime = [[NSMutableDictionary alloc]init];
                _dictionaryToAddTime = [[_arrayResult objectAtIndex:indexPath.row]mutableCopy];
                [_dictionaryToAddTime setObject:_strTime forKey:@"time"];
                
                
                _arrayToDisplayMyPills = [[[NSUserDefaults standardUserDefaults]valueForKey:kMyOwnPillList]mutableCopy];
                if (_arrayToDisplayMyPills.count==0)
                {
                    _arrayToDisplayMyPills = [[NSMutableArray alloc]init];
                }
                [_arrayToDisplayMyPills addObject:_dictionaryToAddTime];
                
                [[NSUserDefaults standardUserDefaults]setObject:_arrayToDisplayMyPills forKey:kMyOwnPillList];
                [[NSUserDefaults standardUserDefaults]synchronize];
                [_tableMyOwnPills reloadData];
            }];
            action;
        })];
        
        UIAlertAction *cancelAction = [UIAlertAction
                                       actionWithTitle:@"Cancel"
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction *action)
                                       { }];
        [alertController addAction:cancelAction];
        
        
        UIPopoverPresentationController *popoverController = alertController.popoverPresentationController;
        popoverController.sourceView = self.view;
        popoverController.sourceRect = [self.view bounds];
        [self presentViewController:alertController  animated:YES completion:nil];
    }
}




#pragma mark
#pragma mark *********************************************** Side Menu Delgates ***********************************************

-(void)func_SideMenuButton
{
    NSLog(@"func Side Menu Button");
    
    [_viewSideMenu removeFromSuperview];
    _viewSideMenu = nil;
    _viewSideMenu = [[SideMenu alloc]init];
    _viewSideMenu.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    _viewSideMenu.sideMenuDelegate=self;
    [self.view addSubview:_viewSideMenu];
}

-(void)func_SideMenu_RemoveSideMenu
{
    [UIView animateWithDuration:0.3 animations:^
     {
         [_viewSideMenu func_SideMenu_RemoveSideMenu];
     }
                     completion:^(BOOL finished)
     {
         _viewSideMenu = nil;
     }];
}




- (void)func_SideMenu_Settings
{
    NSLog(@"Settings Button Tapped from Side Menu");
    [self performSelector:@selector(func_DelayInSettings) withObject:nil afterDelay:0.5];
}

- (void)func_SideMenu_LogOut
{
    NSLog(@"LogOut Button Tapped from Side Menu");
    [self performSelector:@selector(func_DelayInLogOut) withObject:nil afterDelay:0.5];
}


-(void)func_DelayInSettings
{
    NSLog(@"func_DelayInSettings");
    
    SettingsVC *_settings = [[SettingsVC alloc]init];
    [self.navigationController pushViewController:_settings animated:YES];
}


-(void)func_DelayInLogOut
{
    NSLog(@"func_DelayInLogOut");
    
    UIAlertView *_alertLogOut = [[UIAlertView alloc]initWithTitle:@"Logout" message:@"Are you sure you want to logout ?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    _alertLogOut.tag = 45410;
    [_alertLogOut show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 45410 && buttonIndex == 1)
    {
        
        [self.view endEditing:YES];
        
        NSString *_strEmailToServer = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"email"];
        NSString *_strPasswordoServer = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"password"];

        [appDelegate() showIndicator];
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/logoutV2.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:_strEmailToServer forKey:@"email"];
        [Request setPostValue:_strPasswordoServer forKey:@"password"];
        Request.tag = 4510221;
        [Request startAsynchronous];
    }
}



#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 4510221) // logout user
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSString *response = [[NSString alloc] initWithBytes:[[request responseData] bytes] length:[[request responseData] length] encoding:NSUTF8StringEncoding];
            NSLog(@"json to logout user %@",response);
            
            if ([response containsString:@"false0"])
            {
                [UIFunction func_AlertWithTitle:@"" andMessage:@"Incorrect Password"];
            }
            else if ([response containsString:@"false1"])
            {
                [UIFunction func_AlertWithTitle:@"" andMessage:@"Account doesn't exists."];
            }
            else
            {
                [appDelegate() functionToHandleInvalidAccessToken];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
    
}




#pragma mark ***********************************************************************************************************************



#pragma mark
#pragma mark *********************************************** Footer Delgates ***********************************************

- (void)myPillButtonFunction
{
    NSLog(@"myPillButtonFunction");
}
- (void)healthCanadaAlertsButtonFunction
{
    NSLog(@"healthCanadaAlertsButtonFunction");
    
    HealthAlertsVC *log = [[HealthAlertsVC alloc] init];
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    int count = 0;
    
    for( int i=0;i<[ viewContrlls count];i++)
    {
        id obj=[viewContrlls objectAtIndex:i];
        if([obj isKindOfClass:[log class]] )
        {
            count = 1;
            NSLog(@"pop");
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }
    
    if (count == 0)
    {
        NSLog(@"push");
        [self.navigationController pushViewController:log animated:NO];
    }

}
-(void) sickPlottersButtonFunction
{
    NSLog(@"sickPlottersButtonFunction");
    
    SicknessPlotterVC *log = [[SicknessPlotterVC alloc] init];
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    int count = 0;
    
    for( int i=0;i<[ viewContrlls count];i++)
    {
        id obj=[viewContrlls objectAtIndex:i];
        if([obj isKindOfClass:[log class]] )
        {
            count = 1;
            NSLog(@"pop");
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }
    
    if (count == 0)
    {
        NSLog(@"push");
        [self.navigationController pushViewController:log animated:NO];
    }
}



#pragma mark ***********************************************************************************************************************



#pragma mark
#pragma mark func_ScheduleButtonFunction
-(void)func_ScheduleButtonFunction
{
    NSLog(@"func_ScheduleButtonFunction");
    
    [self showWhiteLine:@"0"];
    [landingPageScroll scrollRectToVisible:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height) animated:YES];
}

#pragma mark
#pragma mark func_SearchButtonFunction
-(void)func_SearchButtonFunction
{
    NSLog(@"func_SearchButtonFunction");
    
    [self showWhiteLine:@"1"];
    [landingPageScroll scrollRectToVisible:CGRectMake(0,0,self.view.frame.size.width*2,self.view.frame.size.height) animated:YES];
}



#pragma mark
#pragma mark Scroll View Delegates
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView1
{
    if(scrollView1.tag==857412586)
    {
        CGFloat pageWidth = scrollView1.frame.size.width;
        float fractionalPage = scrollView1.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
        NSLog(@"page is %zd",page);
        
        if (page == 0)
        {
            [self showWhiteLine:@"0"];
            isScheduleVisible = YES;
        }
        else if (page == 1)
        {
            [self showWhiteLine:@"1"];
            isScheduleVisible = NO;
        }
    }
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView1
{
    if(scrollView1.tag==857412586)
    {
        CGFloat pageWidth = scrollView1.frame.size.width;
        float fractionalPage = scrollView1.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
        NSLog(@"page is %zd",page);
        
        if (page == 0)
        {
            [self showWhiteLine:@"0"];
            isScheduleVisible = YES;
        }
        else if (page == 1)
        {
            [self showWhiteLine:@"1"];
            isScheduleVisible = NO;
        }
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}



#pragma mark
#pragma mark Show White Line
-(void)showWhiteLine: (NSString*)type
{
    if ([type isEqualToString:@"0"])
    {
        _whiteLineView.frame = CGRectMake(0, 48, self.view.frame.size.width/2.0, 2);
    }
    else
    {
        _whiteLineView.frame = CGRectMake(self.view.frame.size.width/2.0, 48, self.view.frame.size.width/2.0, 2);
    }
}



-(void)func_FetchAllSearchDomainData
{
    
    NSError *error;
    NSString *strFileContent = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource: @"myPill" ofType: @"txt"] encoding:NSASCIIStringEncoding error:&error];
    if(error) //Handle error
    {
        NSLog(@"File error : %@ ", error.description);
    }
    else
    {
        NSArray *_arrayFromFile = [strFileContent componentsSeparatedByString:@","];
        NSLog(@"File _array : %@ and count is %zd ", _arrayFromFile, _arrayFromFile.count);
        
        NSMutableArray *_arrayForPills = [[NSMutableArray alloc]init];
        for (int counter = 0; counter <_arrayFromFile.count; counter = counter+3)
        {
            NSMutableDictionary *_dictionary = [[NSMutableDictionary alloc]init];
            
            int innerValue = counter;
            if (innerValue%3==0)
            {
                if (_arrayFromFile.count>innerValue)
                {
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[_arrayFromFile objectAtIndex:innerValue]] forKey:@"drug_number"];
                }
                else
                {
                    [_dictionary setObject:@"" forKey:@"drug_number"];
                }
                innerValue++;
            }
            if (innerValue%3 == 1)
            {
                if (_arrayFromFile.count>innerValue)
                {
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[_arrayFromFile objectAtIndex:innerValue]] forKey:@"din_number"];
                }
                else
                {
                    [_dictionary setObject:@"" forKey:@"din_number"];
                }
                innerValue++;
            }
            if (innerValue%3 == 2)
            {
                if (_arrayFromFile.count>innerValue)
                {
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[_arrayFromFile objectAtIndex:innerValue]] forKey:@"pill_name"];
                }
                else
                {
                    [_dictionary setObject:@"" forKey:@"pill_name"];
                }
                innerValue++;
            }
            
            [_arrayForPills addObject:_dictionary];
        }
        
        
        [[NSUserDefaults standardUserDefaults]setObject:_arrayForPills forKey:kSearchDomainForMyPill];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
}



#pragma mark
#pragma mark Search Delegate

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar1
{
    [searchBar1 resignFirstResponder];
    
    for (UIView *view in searchBar1.subviews)
    {
        for (id subview in view.subviews)
        {
            if ( [subview isKindOfClass:[UIButton class]] )
            {
                [subview setEnabled:YES];
                NSLog(@"enableCancelButton");
                return;
            }
        }
    }
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)aSearchBar
{
    [self.view endEditing:YES];
    
    for (UIView *view in aSearchBar.subviews)
    {
        for (id subview in view.subviews)
        {
            if ( [subview isKindOfClass:[UIButton class]] )
            {
                [subview setEnabled:YES];
                NSLog(@"enableCancelButton");
                return;
            }
        }
    }
}

-(void)searchBar:(UISearchBar *)searchBar1 textDidChange:(NSString *)searchText
{
    @try
    {
        if ([searchText length]==0)
        {
            [_arrayResult removeAllObjects];
        }
        else
        {
            [_arrayResult removeAllObjects];
            NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"drug_number contains[c] %@ OR din_number contains[c] %@ OR pill_name contains[c] %@", searchText,searchText,searchText];
            NSArray *filtered = [[[NSUserDefaults standardUserDefaults] valueForKey:kSearchDomainForMyPill] filteredArrayUsingPredicate:resultPredicate];
            _arrayResult = [filtered mutableCopy];
        }
        
        [_tableSeach reloadData];
     }
    @catch (NSException *exception)
    {
        NSLog(@"Exception is %@",exception.description);
    }
}


#pragma mark
#pragma mark Convert Date To String
-(NSString*)func_ConvertDate : (NSDate*)date
{
    NSString *returnDate;
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [formatter setTimeZone:[NSTimeZone defaultTimeZone]];
    [formatter setDateFormat:@"dd MMM yyyy HH:mm"];
    returnDate = [formatter stringFromDate:date];
    return returnDate;
}

-(void)func_SetLocalNotification : (NSDate*)date
{
    UILocalNotification *localNotif = [[UILocalNotification alloc] init];
    localNotif.fireDate = date;
    localNotif.timeZone = [NSTimeZone defaultTimeZone];
    localNotif.alertBody = @"You have a schedule pill for now.";
    localNotif.alertAction = NSLocalizedString(@"View", nil);
    localNotif.soundName = UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotif];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
