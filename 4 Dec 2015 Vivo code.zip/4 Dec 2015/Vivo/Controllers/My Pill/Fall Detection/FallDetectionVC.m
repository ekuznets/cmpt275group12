//
//  FallDetectionVC.m
//  Vivo
//
//  Created by Sukhreet on 03/11/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "FallDetectionVC.h"

@interface FallDetectionVC ()

@end

@implementation FallDetectionVC
{
    UIButton *_btnFallDetetcionStatus;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnBack = [UIFunction createButton:CGRectMake(0, 20, [UIImage imageNamed:@"back_white.png"].size.width, [UIImage imageNamed:@"back_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"back_white.png"] title:nil font:nil titleColor:nil];
    [_btnBack addTarget:self action:@selector(func_BackButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnBack];
    
    UIImageView *_imgViewLogo = [UIFunction createUIImageView:CGRectMake(_btnBack.frame.size.width+_btnBack.frame.origin.x+10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] isLogo:NO];
    [_viewHeader addSubview:_imgViewLogo];
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Fall Detection" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];

    
    
    UILabel *_lblFallDetection = [UIFunction createLable:CGRectMake(20, 70, 150, 50) bckgroundColor:[UIColor clearColor] title:@"Fall Detection" font:[UIFont fontWithName:miscoBold size:16.0] titleColor:[UIColor blackColor]];
    [self.view addSubview:_lblFallDetection];
   
    
    _btnFallDetetcionStatus = [UIFunction createButton:CGRectMake(self.view.frame.size.width-[UIImage imageNamed:@"switchoff.png"].size.width, 70, [UIImage imageNamed:@"switchoff.png"].size.width, [UIImage imageNamed:@"switchoff.png"].size.height) bckgroundColor:nil image:nil title:nil font:nil titleColor:nil];
    [_btnFallDetetcionStatus addTarget:self action:@selector(func_FallDetection:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:_btnFallDetetcionStatus];
    
    
    if ([[NSUserDefaults standardUserDefaults]boolForKey:kFallDetection]==YES)
    {
        [_btnFallDetetcionStatus setBackgroundImage:[UIImage imageNamed:@"switchon.png"] forState:UIControlStateNormal];
    }
    else
    {
        [_btnFallDetetcionStatus setBackgroundImage:[UIImage imageNamed:@"switchoff.png"] forState:UIControlStateNormal];
    }
}


#pragma mark
#pragma mark func_BackButton
-(void)func_BackButton
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)func_FallDetection : (UIButton*)sender
{
    if ([[NSUserDefaults standardUserDefaults]boolForKey:kFallDetection]==YES)
    {
        [[NSUserDefaults standardUserDefaults]setBool:NO forKey:kFallDetection];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [_btnFallDetetcionStatus setBackgroundImage:[UIImage imageNamed:@"switchoff.png"] forState:UIControlStateNormal];
        [appDelegate().knockDetector setIsOn:NO];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:kFallDetection];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [_btnFallDetetcionStatus setBackgroundImage:[UIImage imageNamed:@"switchon.png"] forState:UIControlStateNormal];
        [appDelegate().knockDetector setIsOn:YES];

    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
