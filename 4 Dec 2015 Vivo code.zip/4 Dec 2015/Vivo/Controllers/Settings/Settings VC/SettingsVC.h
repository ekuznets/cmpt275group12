//
//  SettingsVC.h
//  Vivo
//
//  Created by Sukhreet on 31/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsVC : UIViewController

@end
