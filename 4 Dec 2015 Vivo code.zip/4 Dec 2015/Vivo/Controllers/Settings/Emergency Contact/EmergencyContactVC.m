//
//  EmergencyContactVC.m
//  Vivo
//
//  Created by Sukhreet on 22/11/15.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "EmergencyContactVC.h"

@interface EmergencyContactVC () <UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate>

@end

@implementation EmergencyContactVC
{
    UITableView *_tableEmergencyContact;
    BOOL isEditEnable;
    NSMutableDictionary *_dictionaryEmergencyContact;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _dictionaryEmergencyContact = [[NSMutableDictionary alloc]init];
    
    if ([[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]allKeys]containsObject:@"contact"])
    {
        [_dictionaryEmergencyContact setObject:[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"contact"] forKey:@"emergency_contact"];
    }
    else
    {
        [_dictionaryEmergencyContact setObject:@"" forKey:@"emergency_contact"];
    }

    
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnBack = [UIFunction createButton:CGRectMake(0, 20, [UIImage imageNamed:@"back_white.png"].size.width, [UIImage imageNamed:@"back_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"back_white.png"] title:nil font:nil titleColor:nil];
    [_btnBack addTarget:self action:@selector(func_BackButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnBack];
    
    UIImageView *_imgViewLogo = [UIFunction createUIImageView:CGRectMake(_btnBack.frame.size.width+_btnBack.frame.origin.x+10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] isLogo:NO];
    [_viewHeader addSubview:_imgViewLogo];
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Emergency Contact" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];
    
    
    UIButton *_btnEdit = [UIFunction createButton:CGRectMake(self.view.frame.size.width-[UIImage imageNamed:@"edit_white.png"].size.width, 20, [UIImage imageNamed:@"edit_white.png"].size.width, [UIImage imageNamed:@"edit_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"edit_white.png"] title:nil font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor whiteColor]];
    [_btnEdit addTarget:self action:@selector(func_EditButton:) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnEdit];

    
    
    // UITable View which contains all Field
    _tableEmergencyContact = [self createTableView:CGRectMake(0,_viewHeader.frame.size.height+_viewHeader.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height-_viewHeader.frame.size.height-_viewHeader.frame.origin.y) backgroundColor:[UIColor whiteColor]];
    _tableEmergencyContact.showsVerticalScrollIndicator = YES;
    _tableEmergencyContact.layer.cornerRadius = 5.0;
    [self.view addSubview:_tableEmergencyContact];

}


#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}

#pragma mark
#pragma mark func_BackButton
-(void)func_BackButton
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
#pragma mark
-(void)func_EditButton : (UIButton*)sender
{
    NSLog(@"func_EditButton");
    
    if (isEditEnable == NO)
    {
        isEditEnable = YES;
        [sender setTitle:@"Done" forState:UIControlStateNormal];
        [sender setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
    else
    {
        isEditEnable = NO;
        [sender setTitle:@"" forState:UIControlStateNormal];
        [sender setBackgroundImage:[UIImage imageNamed:@"edit_white.png"] forState:UIControlStateNormal];
        [self func_APICallToChangeEmergencyContact];
    }
    
    [_tableEmergencyContact reloadData];
}

-(void)func_APICallToChangeEmergencyContact
{
    NSLog(@"func_APICallToChangeEmergencyContact");
    
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [reach currentReachabilityStatus];
    
    if (netStatus == NotReachable)
    {
        [UIFunction func_Alert_InternetUnavailable];
    }
    else
    {
        NSLog(@"Call API To Change Emergency Contact");
        [self.view endEditing:YES];
        
        NSString *_strEmail = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"email"];
        NSString *_strPassword = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"password"];
        NSString *_strContact = [[NSString stringWithFormat:@"%@",[_dictionaryEmergencyContact valueForKey:@"emergency_contact"]]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        if (_strContact.length==0)
        {
            [UIFunction func_AlertWithTitle:@"Required" andMessage:@"Please enter email address."];
        }
        else if ([UIFunction validateEmail:_strEmail] == 0)
        {
            [UIFunction func_AlertWithTitle:@"Error" andMessage:@"Please enter a valid e-mail address."];
        }
        else
        {
            [appDelegate() showIndicator];
            ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/change_contactV2.php"]]];
            [Request setTimeOutSeconds:300];
            Request.shouldAttemptPersistentConnection   = NO;
            Request.delegate=self;
            [Request setRequestMethod:@"POST"];
            [Request setPostValue:_strEmail forKey:@"email"];
            [Request setPostValue:_strPassword forKey:@"password"];
            [Request setPostValue:_strContact forKey:@"contact"];
            Request.tag = 947490;
            [Request startAsynchronous];
        }
    }

}

#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 947490) // change emergency contact
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[request responseData] options:kNilOptions error:nil];
            NSLog(@"json to change emergency contact %@",json);
            
            if ([json objectForKey:@"response"])
            {
                if ([[[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]allKeys]containsObject:@"contact"])
                {
                    NSMutableDictionary *_dictionary = [[NSMutableDictionary alloc]init];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"] valueForKey:@"contact"]] forKey:@"contact"];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"] valueForKey:@"email"]] forKey:@"email"];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"] valueForKey:@"password"]] forKey:@"password"];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] valueForKey:kLoginData] valueForKey:@"device_token"]] forKey:@"device_token"];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] valueForKey:kLoginData] valueForKey:@"location"]] forKey:@"location"];
                    
                    [[NSUserDefaults standardUserDefaults]setObject:_dictionary forKey:kLoginData];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                }
                else
                {
                    NSMutableDictionary *_dictionary = [[NSMutableDictionary alloc]init];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"] valueForKey:@"contact"]] forKey:@"contact"];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"] valueForKey:@"email"]] forKey:@"email"];
                    [_dictionary setObject:[NSString stringWithFormat:@"%@",[[json objectForKey:@"response"] valueForKey:@"password"]] forKey:@"password"];
                    [_dictionary setObject:@"" forKey:@"device_token"];
                    [_dictionary setObject:@"" forKey:@"location"];
                    
                    [[NSUserDefaults standardUserDefaults]setObject:_dictionary forKey:kLoginData];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                }
                
                
                [UIFunction func_AlertWithTitle:@"Sucess" andMessage:@"Emergency Contact updated successfully."];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else if ([json objectForKey:@"error"])
            {
                [UIFunction func_AlertWithTitle:@"Error" andMessage:[json objectForKey:@"error"]];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
}



#pragma mark
#pragma mark Table View Data Source and Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];
    

    NSString *_strEmergencyEmail = [_dictionaryEmergencyContact valueForKey:@"emergency_contact"];
    
    UITextField *_textField = [[UITextField alloc]init];
    _textField.frame = CGRectMake(20, 0, tableView.frame.size.width-40, frame.size.height);
    _textField.borderStyle = UITextBorderStyleNone;
    _textField.font = [UIFont fontWithName:miscoRegular size:16];
    _textField.keyboardType = UIKeyboardTypeDefault;
    _textField.returnKeyType = UIReturnKeyDone;
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textField.tag = 100;
    _textField.text = _strEmergencyEmail;
    _textField.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    _textField.delegate = self;
    _textField.secureTextEntry = NO;
    _textField.placeholder = @"Emergency Contact";
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _textField.textColor = [UIColor blackColor];
    _textField.leftViewMode=UITextFieldViewModeAlways;
    _textField.autocapitalizationType= UITextAutocapitalizationTypeNone;
    _textField.autocorrectionType = UITextAutocorrectionTypeNo;
    _textField.backgroundColor = [UIColor clearColor];
    [self.view endEditing:YES];
    [cell.contentView addSubview:_textField];
    
    if (isEditEnable == YES)
    {
        _textField.userInteractionEnabled = true;
    }
    else
    {
        _textField.userInteractionEnabled = false;
    }
    
    
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(_textField.frame.origin.x, frame.size.height-1, tableView.frame.size.width, 1) bckgroundColor:[UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]];
    [cell.contentView addSubview:_viewDivider];
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.userInteractionEnabled = true;
    return cell;
    
}


#pragma mark
#pragma mark TextField Delegate
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 100) //emergency_email
    {
        NSString *_strEmail = [[textField.text stringByReplacingCharactersInRange:range withString:string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [_dictionaryEmergencyContact setValue:_strEmail forKey:@"emergency_contact"];
    }
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    if (textField.tag == 100) //emergency_email
    {
        [_dictionaryEmergencyContact setValue:@"" forKey:@"emergency_contact"];
    }    
    return YES;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
