//
//  EmergencyContactVC.h
//  Vivo
//
//  Created by Ankit Goyal on 22/11/15.
//  Copyright © 2015 Epitome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmergencyContactVC : UIViewController

@end
