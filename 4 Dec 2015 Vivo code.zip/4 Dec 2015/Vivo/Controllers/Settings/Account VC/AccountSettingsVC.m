//
//  AccountSettingsVC.m
//  Vivo
//
//  Created by Sukhreet on 31/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "AccountSettingsVC.h"

@interface AccountSettingsVC () <UITableViewDataSource, UITableViewDelegate, UIWebViewDelegate>

@end

@implementation AccountSettingsVC
{
    UITableView *_tableAccountSettings;
    NSMutableArray *_arraySettings;
    NSMutableArray *_arrayImages;
    UIView *viewContactUs;

}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    _arraySettings = [[NSMutableArray alloc]initWithObjects:@"Contact us", nil];
    _arrayImages = [[NSMutableArray alloc]initWithObjects:@"phone_icon.png", nil];

    
    
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnBack = [UIFunction createButton:CGRectMake(0, 20, [UIImage imageNamed:@"back_white.png"].size.width, [UIImage imageNamed:@"back_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"back_white.png"] title:nil font:nil titleColor:nil];
    [_btnBack addTarget:self action:@selector(func_BackButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnBack];
    
    UIImageView *_imgViewLogo = [UIFunction createUIImageView:CGRectMake(_btnBack.frame.size.width+_btnBack.frame.origin.x+10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] isLogo:NO];
    [_viewHeader addSubview:_imgViewLogo];
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Account Settings" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];
    
    // UITable View which contains all Field
    _tableAccountSettings = [self createTableView:CGRectMake(0,_viewHeader.frame.size.height+_viewHeader.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height-_viewHeader.frame.size.height-_viewHeader.frame.origin.y) backgroundColor:[UIColor whiteColor]];
    _tableAccountSettings.showsVerticalScrollIndicator = YES;
    _tableAccountSettings.layer.cornerRadius = 5.0;
    [self.view addSubview:_tableAccountSettings];
}


#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}

#pragma mark
#pragma mark func_BackButton
-(void)func_BackButton
{
    [self.navigationController popViewControllerAnimated:YES];
}



#pragma mark
#pragma mark Table View Data Source and Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_arraySettings count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];
    
    
    UIImageView *_imgViewIcons = [UIFunction createUIImageView:CGRectMake(10, frame.size.height/2.0-[UIImage imageNamed:[_arrayImages objectAtIndex:indexPath.row]].size.height/2.0, [UIImage imageNamed:[_arrayImages objectAtIndex:indexPath.row]].size.width, [UIImage imageNamed:[_arrayImages objectAtIndex:indexPath.row]].size.height) backgroundColor:[UIColor clearColor] image:[UIImage imageNamed:[_arrayImages objectAtIndex:indexPath.row]] isLogo:NO];
    [cell.contentView addSubview:_imgViewIcons];
    
    
    UILabel *_lblTableCell = [UIFunction createLable:CGRectMake(60, 10, 200, 30) bckgroundColor:[UIColor clearColor] title:[_arraySettings objectAtIndex:indexPath.row] font:[UIFont fontWithName:miscoRegular size:16.0] titleColor:[UIColor blackColor]];
    [cell.contentView addSubview:_lblTableCell];
    
    
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(10, frame.size.height-1, tableView.frame.size.width, 1) bckgroundColor:[UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]];
    [cell.contentView addSubview:_viewDivider];
    
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.userInteractionEnabled = true;
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) // contact us
    {
        [viewContactUs removeFromSuperview];
        viewContactUs = nil;
        viewContactUs = [[UIView alloc]init];
        viewContactUs.userInteractionEnabled = true;
        viewContactUs.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height);
        viewContactUs.backgroundColor = [UIColor colorWithRed:238.0/255 green:238.0/255 blue:238.0/255 alpha:1.0];
        [self.view addSubview:viewContactUs];
        
        
        // Header View
        UIView *_headerViewOfTerms = [UIFunction createHeader:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
        _headerViewOfTerms.layer.shadowColor = [UIColor grayColor].CGColor;
        _headerViewOfTerms.layer.shadowOffset = CGSizeMake(1.0, 1.0);
        _headerViewOfTerms.layer.shadowOpacity = 1.0;
        _headerViewOfTerms.layer.shadowRadius = 2.0;
        [viewContactUs addSubview:_headerViewOfTerms];
        
        // Label On Header
        UILabel *_lblHeaderOFterms = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Contact us" font:[UIFont fontWithName:miscoBold size:18] titleColor:[UIColor whiteColor]];
        _lblHeaderOFterms.textAlignment = NSTextAlignmentCenter;
        [_headerViewOfTerms addSubview:_lblHeaderOFterms];
        
        
        UIButton *_btnCancel = [UIFunction createButton:CGRectMake(0, 20, [UIImage imageNamed:@"back_white.png"].size.width, [UIImage imageNamed:@"back_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"back_white.png"] title:nil font:[UIFont fontWithName:miscoBold size:16] titleColor:[UIColor colorWithRed:66.0/255 green:133.0/255 blue:244.0/255 alpha:1.0]];
        [_btnCancel addTarget:self action:@selector(functionToRemoveTContactUs) forControlEvents:UIControlEventTouchUpInside];
        [_headerViewOfTerms addSubview:_btnCancel];
        

        UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, _headerViewOfTerms.frame.size.height+_headerViewOfTerms.frame.origin.y+5, self.view.frame.size.width , self.view.frame.size.height-_headerViewOfTerms.frame.size.height-_headerViewOfTerms.frame.origin.y-10)];
        NSURL *targetURL = [NSURL URLWithString:@"http://esotericrambling.com/team-information/"];
        NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
        [webView loadRequest:request];
        webView.delegate = self;
        webView.scalesPageToFit=YES;
        [viewContactUs addSubview:webView];
        
        
        UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        activityView.center = self.view.center;
        [activityView startAnimating];
        activityView.tag = 964789;
        [webView addSubview:activityView];

        
        [UIView animateWithDuration:.4f animations:^{
            viewContactUs.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        } completion:^(BOOL finished) {
        }];
        
    }
}

-(void)functionToRemoveTContactUs
{
    [UIView animateWithDuration:.4f animations:^{
        viewContactUs.frame=CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height);
        
    } completion:^(BOOL finished) {
        
        [viewContactUs removeFromSuperview];
        viewContactUs = nil;
    }];
}


#pragma mark
#pragma mark Web View Delegates
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    UIActivityIndicatorView *indicator = (UIActivityIndicatorView*)[self.view viewWithTag:964789];
    [indicator removeFromSuperview];
    indicator = nil;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    UIActivityIndicatorView *indicator = (UIActivityIndicatorView*)[self.view viewWithTag:964789];
    [indicator removeFromSuperview];
    indicator = nil;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
