//
//  HealthAlertsVC.m
//  Vivo
//
//  Created by Sukhreet on 31/10/2015.
//  Copyright © 2015 Apto. All rights reserved.
//

#import "HealthAlertsVC.h"
#import "MyPillVC.h"
#import "SideMenu.h"
#import "CustomFooterView.h"
#import "SicknessPlotterVC.h"
#import "SettingsVC.h"



@interface HealthAlertsVC () <sideMenuProtocol, customFooterMethod, UIWebViewDelegate,UITableViewDataSource, UITableViewDelegate>

@end

@implementation HealthAlertsVC
{
    SideMenu *_viewSideMenu;
    CustomFooterView *footerView;
    UITableView *_tableHealthAlertVC;
    NSArray *_arrayHealthAlerts;
    UIView *_viewSelected;
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [footerView changeImage:@"2"];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    _arrayHealthAlerts = [NSArray arrayWithObjects:@"Consumer Products",@"Food",@"Health Products",@"All", nil];
    
    UIView *_viewHeader = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
    [self.view addSubview:_viewHeader];
    
    UIButton *_btnSideMenu = [UIFunction createButton:CGRectMake(10, 25, [UIImage imageNamed:@"logo_header.png"].size.width, [UIImage imageNamed:@"logo_header.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"logo_header.png"] title:nil font:nil titleColor:nil];
    [_btnSideMenu addTarget:self action:@selector(func_SideMenuButton) forControlEvents:UIControlEventTouchUpInside];
    [_viewHeader addSubview:_btnSideMenu];
    
    
    UILabel *_lblHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:@"Health Canada Alerts" font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
    _lblHeader.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_lblHeader];

    
    [footerView removeFromSuperview];
    footerView = nil;
    footerView = [[CustomFooterView alloc]init];
    footerView.frame = CGRectMake(0, self.view.frame.size.height-49, self.view.frame.size.width, 49);
    [footerView setBackgroundColor:[UIColor colorWithRed:247.0/255 green:247.0/255 blue:247.0/255 alpha:1.0]];
    footerView.footerDelegate=self;
    [self.view addSubview:footerView];
    [footerView changeImage:@"2"];
    
    
    _tableHealthAlertVC = [self createTableView:CGRectMake(0,_viewHeader.frame.size.height+_viewHeader.frame.origin.y, self.view.frame.size.width, footerView.frame.origin.y-_viewHeader.frame.size.height-_viewHeader.frame.origin.y) backgroundColor:[UIColor whiteColor]];
    _tableHealthAlertVC.showsVerticalScrollIndicator = YES;
    [self.view addSubview:_tableHealthAlertVC];
    
    

}

#pragma mark
#pragma mark Create Table
-(UITableView*) createTableView : (CGRect)frame backgroundColor:(UIColor*)backgroundColor
{
    UITableView *_tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate = self;
    _tableView.backgroundColor=backgroundColor;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.alwaysBounceVertical = NO;
    [_tableView setAllowsSelection:YES];
    return _tableView;
}


#pragma mark
#pragma mark Table View Data Source and Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_arrayHealthAlerts count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    else
    {
        UIView *subview;
        while ((subview= [[[cell contentView]subviews]lastObject])!=nil)
        {
            [subview removeFromSuperview];
        }
    }
    
    CGRect frame = [tableView rectForRowAtIndexPath:indexPath];
    
    
    UILabel *_lblOption = [UIFunction createLable:CGRectMake(25, 0, tableView.frame.size.width, frame.size.height) bckgroundColor:[UIColor clearColor] title:[_arrayHealthAlerts objectAtIndex:indexPath.row] font:[UIFont fontWithName:miscoBold size:14] titleColor:[UIColor blackColor]];
    [cell.contentView addSubview:_lblOption];
    
    
    UIView *_viewDivider = [UIFunction createUIViews:CGRectMake(25, frame.size.height-1, tableView.frame.size.width-50, 1) bckgroundColor:[UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]];
    [cell.contentView addSubview:_viewDivider];
    
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.userInteractionEnabled = true;
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSURL *targetURL;

    if (indexPath.row == 0) // consumer products
    {
        NSString *_strURL = @"http://healthycanadians.gc.ca/drugs-products-medicaments-produits/index-eng.php";
        NSString *encodedString=[_strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        targetURL = [NSURL URLWithString:encodedString];
    }
    else if (indexPath.row == 1) // food
    {
        NSString *_strURL = @"http://healthycanadians.gc.ca/eating-nutrition/index-eng.php";
        NSString *encodedString=[_strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        targetURL = [NSURL URLWithString:encodedString];
    }
    else if (indexPath.row == 2) // health products
    {
        NSString *_strURL = @"http://healthycanadians.gc.ca/security-securite/index-eng.php";
        NSString *encodedString=[_strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        targetURL = [NSURL URLWithString:encodedString];
    }
    else if (indexPath.row == 3) // all
    {
        NSString *_strURL = @"http://healthycanadians.gc.ca/index-eng.php";
        NSString *encodedString=[_strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        targetURL = [NSURL URLWithString:encodedString];
    }
    
    
    [_viewSelected removeFromSuperview];
    _viewSelected = nil;
    _viewSelected = [UIFunction createUIViews:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height-50) bckgroundColor:[UIColor clearColor]];
    [self.view addSubview:_viewSelected];
    
    [UIView animateWithDuration:0.3 animations:^{
        _viewSelected.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-50);
    } completion:^(BOOL finished) {
        
        UIView *_viewTopOnSelectedView = [UIFunction createUIViews:CGRectMake(0, 0, self.view.frame.size.width, 64) bckgroundColor:[UIColor colorWithRed:6.0/255 green:54.0/255 blue:109.0/255 alpha:1.0]];
        [_viewSelected addSubview:_viewTopOnSelectedView];
        
        UIButton *_btnBack = [UIFunction createButton:CGRectMake(10, 20, [UIImage imageNamed:@"back_white.png"].size.width, [UIImage imageNamed:@"back_white.png"].size.height) bckgroundColor:[UIColor clearColor] image:[UIImage imageNamed:@"back_white.png"] title:nil font:nil titleColor:nil];
        [_btnBack addTarget:self action:@selector(func_RemoveSelectedWebPage) forControlEvents:UIControlEventTouchUpInside];
        [_viewSelected addSubview:_btnBack];
        
        
        UILabel *_lblSelectedHeader = [UIFunction createLable:CGRectMake(0, 20, self.view.frame.size.width, 44) bckgroundColor:[UIColor clearColor] title:[NSString stringWithFormat:@"%@",[_arrayHealthAlerts objectAtIndex:indexPath.row]] font:[UIFont fontWithName:miscoBold size:18.0] titleColor:[UIColor whiteColor]];
        _lblSelectedHeader.textAlignment = NSTextAlignmentCenter;
        [_viewSelected addSubview:_lblSelectedHeader];
        
        
        UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 70, self.view.frame.size.width , footerView.frame.origin.y-70)];
        NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
        [webView loadRequest:request];
        webView.delegate = self;
        webView.scalesPageToFit=YES;
        [_viewSelected addSubview:webView];
        
        
        UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        activityView.center = self.view.center;
        [activityView startAnimating];
        activityView.tag = 964789;
        [webView addSubview:activityView];

    }];
}

-(void)func_RemoveSelectedWebPage
{
    [UIView animateWithDuration:0.3 animations:^{
        _viewSelected.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height-50);
    } completion:^(BOOL finished) {
        [_viewSelected removeFromSuperview];
        _viewSelected = nil;
    }];
}


#pragma mark
#pragma mark *********************************************** Side Menu Delgates ***********************************************

-(void)func_SideMenuButton
{
    NSLog(@"func Side Menu Button");
    
    [_viewSideMenu removeFromSuperview];
    _viewSideMenu = nil;
    _viewSideMenu = [[SideMenu alloc]init];
    _viewSideMenu.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    _viewSideMenu.sideMenuDelegate=self;
    [self.view addSubview:_viewSideMenu];
}

-(void)func_SideMenu_RemoveSideMenu
{
    [UIView animateWithDuration:0.3 animations:^
     {
         [_viewSideMenu func_SideMenu_RemoveSideMenu];
     }
                     completion:^(BOOL finished)
     {
         _viewSideMenu = nil;
     }];
}




- (void)func_SideMenu_Settings
{
    NSLog(@"Settings Button Tapped from Side Menu");
    [self performSelector:@selector(func_DelayInSettings) withObject:nil afterDelay:0.5];
}

- (void)func_SideMenu_LogOut
{
    NSLog(@"LogOut Button Tapped from Side Menu");
    [self performSelector:@selector(func_DelayInLogOut) withObject:nil afterDelay:0.5];
}


-(void)func_DelayInSettings
{
    NSLog(@"func_DelayInSettings");
    SettingsVC *_settings = [[SettingsVC alloc]init];
    [self.navigationController pushViewController:_settings animated:YES];
}


-(void)func_DelayInLogOut
{
    NSLog(@"func_DelayInLogOut");
    
    UIAlertView *_alertLogOut = [[UIAlertView alloc]initWithTitle:@"Logout" message:@"Are you sure you want to logout ?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    _alertLogOut.tag = 45410;
    [_alertLogOut show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 45410 && buttonIndex == 1)
    {
        
        [self.view endEditing:YES];
        
        NSString *_strEmailToServer = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"email"];
        NSString *_strPasswordoServer = [[[NSUserDefaults standardUserDefaults]valueForKey:kLoginData]valueForKey:@"password"];
        
        [appDelegate() showIndicator];
        ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://52.89.151.217/logoutV2.php"]]];
        [Request setTimeOutSeconds:300];
        Request.shouldAttemptPersistentConnection   = NO;
        Request.delegate=self;
        [Request setRequestMethod:@"POST"];
        [Request setPostValue:_strEmailToServer forKey:@"email"];
        [Request setPostValue:_strPasswordoServer forKey:@"password"];
        Request.tag = 4510221;
        [Request startAsynchronous];

    }
}


#pragma mark
#pragma mark ASIFormDataRequest Delegates
- (void)requestStarted:(ASIHTTPRequest *)request
{
    NSLog(@"starteeeddd with tag %d",(int)request.tag);
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed with tag is %zd and error is %@",request.tag,request.error);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    if (request.tag == 4510221) // logout user
    {
        @try
        {
            [appDelegate() hideIndicator];
            
            NSString *response = [[NSString alloc] initWithBytes:[[request responseData] bytes] length:[[request responseData] length] encoding:NSUTF8StringEncoding];
            NSLog(@"json to logout user %@",response);
            
            if ([response containsString:@"false0"])
            {
                [UIFunction func_AlertWithTitle:@"" andMessage:@"Incorrect Password"];
            }
            else if ([response containsString:@"false1"])
            {
                [UIFunction func_AlertWithTitle:@"" andMessage:@"Account doesn't exists."];
            }
            else
            {
                [appDelegate() functionToHandleInvalidAccessToken];
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"Exception is %@",exception.description);
        }
    }
    
}




#pragma mark ***********************************************************************************************************************



#pragma mark
#pragma mark *********************************************** Footer Delgates ***********************************************

- (void)myPillButtonFunction
{
    NSLog(@"myPillButtonFunction");
    
    MyPillVC *log = [[MyPillVC alloc] init];
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    int count = 0;
    
    for( int i=0;i<[ viewContrlls count];i++)
    {
        id obj=[viewContrlls objectAtIndex:i];
        if([obj isKindOfClass:[log class]] )
        {
            count = 1;
            NSLog(@"pop");
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }
    
    if (count == 0)
    {
        NSLog(@"push");
        [self.navigationController pushViewController:log animated:NO];
    }
}

- (void)healthCanadaAlertsButtonFunction
{
    NSLog(@"healthCanadaAlertsButtonFunction");
}
-(void) sickPlottersButtonFunction
{
    NSLog(@"sickPlottersButtonFunction");
    
    SicknessPlotterVC *log = [[SicknessPlotterVC alloc] init];
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    int count = 0;
    
    for( int i=0;i<[ viewContrlls count];i++)
    {
        id obj=[viewContrlls objectAtIndex:i];
        if([obj isKindOfClass:[log class]] )
        {
            count = 1;
            NSLog(@"pop");
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }
    
    if (count == 0)
    {
        NSLog(@"push");
        [self.navigationController pushViewController:log animated:NO];
    }
}



#pragma mark ***********************************************************************************************************************



#pragma mark
#pragma mark Webview Delegates
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    UIActivityIndicatorView *indicator = (UIActivityIndicatorView*)[self.view viewWithTag:964789];
    [indicator removeFromSuperview];
    indicator = nil;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"________________________________ %@",error.description);
    UIActivityIndicatorView *indicator = (UIActivityIndicatorView*)[self.view viewWithTag:964789];
    [indicator removeFromSuperview];
    indicator = nil;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
